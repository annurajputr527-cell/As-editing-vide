# Preserve Firestore data models for CustomClassMapper reflection
-keepclassmembers class com.example.data.model.** {
    <fields>;
    <init>(...);
}
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Preserve Media3 & Credential Manager reflective classes if minification is enabled
-keepclassmembers class * implements androidx.media3.common.Effect { *; }
