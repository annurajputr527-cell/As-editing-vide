package com.example

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.Collections
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.auth.authStateFlow
import com.example.auth.signOut
import com.example.data.model.EditProject
import com.example.data.model.RoyalFilterPresets
import com.example.data.repository.StudioRepository
import com.example.ui.screens.AccountScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.GalleryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PhotoEditorScreen
import com.example.ui.screens.VideoEditorScreen
import com.example.ui.theme.ASEditingTheme
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OnyxCard
import com.example.ui.theme.RoyalBorder
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalVoid
import com.example.ui.viewmodel.StudioViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
        )
        setContent {
            ASEditingTheme {
                ASEditingApp()
            }
        }
    }
}

private enum class StudioTab(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String,
) {
    STUDIO("Studio", Icons.Filled.Home, Icons.Outlined.Home, "nav_tab_studio"),
    EXPORTS("Gallery", Icons.Filled.Collections, Icons.Outlined.Collections, "nav_tab_gallery"),
    ACCOUNT("Account", Icons.Filled.Person, Icons.Outlined.Person, "nav_tab_account"),
}

private enum class ActiveEditor {
    NONE,
    PHOTO,
    VIDEO,
}

@Composable
fun ASEditingApp() {
    val auth = Firebase.auth
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)

    val user = currentUser
    if (user == null) {
        AuthScreen(
            onAuthSuccess = { /* AuthStateListener drives navigation reactively */ }
        )
    } else {
        key(user.uid) {
            AuthenticatedStudioShell(user = user)
        }
    }
}

@Composable
private fun AuthenticatedStudioShell(user: FirebaseUser) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: StudioViewModel = viewModel(
        key = user.uid,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                StudioViewModel(
                    repository = StudioRepository(db),
                    currentUserId = user.uid,
                    initialDisplayName = user.displayName ?: "Royal Creator",
                )
            }
        }
    )

    val userProfileState by viewModel.userProfile.collectAsStateWithLifecycle()
    val projectsState by viewModel.projectsState.collectAsStateWithLifecycle()
    val customPresetsState by viewModel.customPresetsState.collectAsStateWithLifecycle()
    val photoState by viewModel.photoState.collectAsStateWithLifecycle()
    val videoState by viewModel.videoState.collectAsStateWithLifecycle()
    val galleryExports by viewModel.galleryExports.collectAsStateWithLifecycle()
    val isLoadingExports by viewModel.isLoadingExports.collectAsStateWithLifecycle()

    var currentTab by rememberSaveable { mutableStateOf(StudioTab.STUDIO) }
    var activeEditor by rememberSaveable { mutableStateOf(ActiveEditor.NONE) }
    var pendingPhotoProject by remember { mutableStateOf<EditProject?>(null) }
    var pendingVideoProject by remember { mutableStateOf<EditProject?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            val project = pendingPhotoProject
            pendingPhotoProject = null
            if (uri != null) {
                viewModel.openPhotoForEditing(context, uri, project)
                activeEditor = ActiveEditor.PHOTO
            }
        }
    )

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            val project = pendingVideoProject
            pendingVideoProject = null
            if (uri != null) {
                viewModel.openVideoForEditing(uri, project)
                activeEditor = ActiveEditor.VIDEO
            }
        }
    )

    when (activeEditor) {
        ActiveEditor.PHOTO -> {
            BackHandler { activeEditor = ActiveEditor.NONE }
            PhotoEditorScreen(
                state = photoState,
                customPresetsState = customPresetsState,
                onBack = { activeEditor = ActiveEditor.NONE },
                onPickAnotherPhoto = {
                    pendingPhotoProject = null
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                onTitleChange = viewModel::updatePhotoTitle,
                onApplyPreset = viewModel::applyPhotoPreset,
                onApplyCustomPreset = viewModel::applyCustomPresetToPhoto,
                onSaveCustomPreset = viewModel::saveCurrentPhotoGradeAsPreset,
                onDeleteCustomPreset = viewModel::deleteCustomPreset,
                onBrightnessChange = { v -> viewModel.updatePhotoAdjustments { it.copy(brightness = v) } },
                onContrastChange = { v -> viewModel.updatePhotoAdjustments { it.copy(contrast = v) } },
                onSaturationChange = { v -> viewModel.updatePhotoAdjustments { it.copy(saturation = v) } },
                onWarmthChange = { v -> viewModel.updatePhotoAdjustments { it.copy(warmth = v) } },
                onVignetteChange = { v -> viewModel.updatePhotoAdjustments { it.copy(vignette = v) } },
                onRotate90 = viewModel::rotatePhoto90,
                onCropAspectChange = { aspect ->
                    viewModel.updatePhotoAdjustments { it.copy(cropAspect = aspect) }
                },
                onOverlayTextChange = { text ->
                    viewModel.updatePhotoAdjustments { it.copy(overlayText = text) }
                },
                onResetAdjustments = { viewModel.applyPhotoPreset(RoyalFilterPresets.builtIn[0]) },
                onToggleCompare = viewModel::togglePhotoCompare,
                onSaveToCloud = viewModel::savePhotoProjectToCloud,
                onExportToGallery = { viewModel.exportPhotoToGallery(context) },
                onDismissStatus = viewModel::clearPhotoStatus,
            )
        }

        ActiveEditor.VIDEO -> {
            BackHandler { activeEditor = ActiveEditor.NONE }
            VideoEditorScreen(
                state = videoState,
                customPresetsState = customPresetsState,
                onBack = { activeEditor = ActiveEditor.NONE },
                onPickVideo = {
                    pendingVideoProject = null
                    videoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                },
                onTitleChange = viewModel::updateVideoTitle,
                onDurationResolved = viewModel::onVideoDurationResolved,
                onApplyPreset = viewModel::applyVideoPreset,
                onApplyCustomPreset = viewModel::applyCustomPresetToVideo,
                onBrightnessChange = { v -> viewModel.updateVideoAdjustments { it.copy(brightness = v) } },
                onContrastChange = { v -> viewModel.updateVideoAdjustments { it.copy(contrast = v) } },
                onSaturationChange = { v -> viewModel.updateVideoAdjustments { it.copy(saturation = v) } },
                onWarmthChange = { v -> viewModel.updateVideoAdjustments { it.copy(warmth = v) } },
                onTrimChange = { startMs, endMs ->
                    viewModel.updateVideoAdjustments { it.copy(trimStartMs = startMs, trimEndMs = endMs) }
                },
                onSpeedChange = { speed ->
                    viewModel.updateVideoAdjustments { it.copy(playbackSpeed = speed) }
                },
                onMuteChange = { muted ->
                    viewModel.updateVideoAdjustments { it.copy(muteAudio = muted) }
                },
                onRotate90 = viewModel::rotateVideo90,
                onCropAspectChange = { aspect ->
                    viewModel.updateVideoAdjustments { it.copy(cropAspect = aspect) }
                },
                onOverlayTextChange = { text ->
                    viewModel.updateVideoAdjustments { it.copy(overlayText = text) }
                },
                onResetAdjustments = { viewModel.applyVideoPreset(RoyalFilterPresets.builtIn[0]) },
                onSaveToCloud = viewModel::saveVideoProjectToCloud,
                onExportToGallery = { viewModel.exportVideoToGallery(context) },
                onCancelExport = viewModel::cancelVideoExport,
                onDismissStatus = viewModel::clearVideoStatus,
            )
        }

        ActiveEditor.NONE -> {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .background(ObsidianBlack),
            ) {
                val useRail = maxWidth >= 600.dp
                Scaffold(
                    containerColor = ObsidianBlack,
                    contentWindowInsets = WindowInsets.statusBars,
                    topBar = {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .windowInsetsPadding(WindowInsets.statusBars),
                            color = RoyalVoid,
                            border = BorderStroke(1.dp, RoyalBorder),
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 20.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = "A S EDITING",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = ChampagneGold,
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Text(
                                    text = "ROYAL 24K",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = RoyalGold,
                                )
                            }
                        }
                    },
                    bottomBar = {
                        if (!useRail) {
                            Surface(
                                color = RoyalVoid,
                                border = BorderStroke(1.dp, RoyalBorder),
                            ) {
                                NavigationBar(
                                    containerColor = RoyalVoid,
                                    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
                                ) {
                                    StudioTab.entries.forEach { tab ->
                                        val selected = currentTab == tab
                                        NavigationBarItem(
                                            selected = selected,
                                            onClick = { currentTab = tab },
                                            modifier = Modifier.testTag(tab.testTag),
                                            icon = {
                                                Icon(
                                                    imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                    contentDescription = tab.label,
                                                )
                                            },
                                            label = {
                                                Text(
                                                    text = tab.label,
                                                    style = MaterialTheme.typography.labelSmall,
                                                )
                                            },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = ChampagneGold,
                                                selectedTextColor = ChampagneGold,
                                                unselectedIconColor = MutedSilver,
                                                unselectedTextColor = MutedSilver,
                                                indicatorColor = OnyxCard,
                                            ),
                                        )
                                    }
                                }
                            }
                        }
                    },
                ) { innerPadding ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding),
                    ) {
                        if (useRail) {
                            NavigationRail(
                                containerColor = RoyalVoid,
                                modifier = Modifier.fillMaxHeight(),
                            ) {
                                Spacer(modifier = Modifier.height(16.dp))
                                StudioTab.entries.forEach { tab ->
                                    val selected = currentTab == tab
                                    NavigationRailItem(
                                        selected = selected,
                                        onClick = { currentTab = tab },
                                        modifier = Modifier.testTag(tab.testTag),
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                contentDescription = tab.label,
                                            )
                                        },
                                        label = { Text(tab.label) },
                                        colors = NavigationRailItemDefaults.colors(
                                            selectedIconColor = ChampagneGold,
                                            selectedTextColor = ChampagneGold,
                                            unselectedIconColor = MutedSilver,
                                            unselectedTextColor = MutedSilver,
                                            indicatorColor = OnyxCard,
                                        ),
                                    )
                                }
                            }
                        }

                        Box(modifier = Modifier.weight(1f)) {
                            when (currentTab) {
                                StudioTab.STUDIO -> HomeScreen(
                                    userProfileState = userProfileState,
                                    projectsState = projectsState,
                                    onPickPhoto = {
                                        pendingPhotoProject = null
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    onTrySamplePhoto = {
                                        viewModel.openPhotoForEditing(context, null, null)
                                        activeEditor = ActiveEditor.PHOTO
                                    },
                                    onPickVideo = {
                                        pendingVideoProject = null
                                        videoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                        )
                                    },
                                    onOpenProject = { project ->
                                        if (project.mediaType == "video") {
                                            viewModel.openVideoForEditing(null, project)
                                            activeEditor = ActiveEditor.VIDEO
                                        } else {
                                            viewModel.openPhotoForEditing(context, null, project)
                                            activeEditor = ActiveEditor.PHOTO
                                        }
                                    },
                                    onDeleteProject = viewModel::deleteProject,
                                )

                                StudioTab.EXPORTS -> GalleryScreen(
                                    exports = galleryExports,
                                    isLoading = isLoadingExports,
                                    onRefresh = { viewModel.refreshGalleryExports(context) },
                                )

                                StudioTab.ACCOUNT -> AccountScreen(
                                    userEmail = user.email,
                                    userDisplayName = user.displayName,
                                    userProfileState = userProfileState,
                                    onSavePreferences = viewModel::updateProfilePreferences,
                                    onSignOut = {
                                        signOut(
                                            credentialManager = credentialManager,
                                            scope = coroutineScope,
                                        )
                                    },
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
