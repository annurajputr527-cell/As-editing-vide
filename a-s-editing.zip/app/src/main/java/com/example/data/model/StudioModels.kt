package com.example.data.model

import android.net.Uri
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class CropAspect(val label: String, val ratio: Float?) {
    ORIGINAL("Free", null),
    SQUARE_1_1("1:1", 1f),
    PORTRAIT_4_5("4:5", 4f / 5f),
    CINEMA_16_9("16:9", 16f / 9f),
    VERTICAL_9_16("9:16", 9f / 16f),
}

enum class ExportQuality(val key: String, val label: String, val targetHeight: Int?) {
    ORIGINAL("ORIGINAL", "Original", null),
    HD_1080("HD_1080", "1080p HD", 1080),
    FAST_720("FAST_720", "720p Fast", 720),
}

data class FilterPreset(
    val name: String,
    val brightness: Float,
    val contrast: Float,
    val saturation: Float,
    val warmth: Float,
    val vignette: Float,
)

object RoyalFilterPresets {
    val builtIn = listOf(
        FilterPreset("Original", 0f, 1f, 1f, 0f, 0f),
        FilterPreset("24K Gold", 0.04f, 1.18f, 1.22f, 0.28f, 0.25f),
        FilterPreset("Royal Noir", -0.04f, 1.38f, 0f, 0f, 0.42f),
        FilterPreset("Obsidian", -0.06f, 1.32f, 0.85f, -0.10f, 0.35f),
        FilterPreset("Champagne", 0.08f, 1.08f, 0.92f, 0.34f, 0.15f),
        FilterPreset("Velvet Fade", 0.05f, 0.90f, 0.78f, 0.12f, 0.30f),
    )
}

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val studioHandle: String = "A S Royal Studio",
    val defaultQuality: String = ExportQuality.HD_1080.key,
    val watermarkEnabled: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class EditProject(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val mediaType: String = "photo",
    val sourceUri: String = "",
    val presetName: String = "Original",
    val brightness: Double = 0.0,
    val contrast: Double = 1.0,
    val saturation: Double = 1.0,
    val warmth: Double = 0.0,
    val vignette: Double = 0.0,
    val rotationDegrees: Long = 0L,
    val cropAspect: String = CropAspect.ORIGINAL.name,
    val overlayText: String = "",
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 0L,
    val playbackSpeed: Double = 1.0,
    val muteAudio: Boolean = false,
    val exportCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class CustomPreset(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val brightness: Double = 0.0,
    val contrast: Double = 1.0,
    val saturation: Double = 1.0,
    val warmth: Double = 0.0,
    val vignette: Double = 0.0,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

data class GalleryExportItem(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val isVideo: Boolean,
    val sizeBytes: Long,
    val durationMs: Long,
    val dateAddedSec: Long,
)
