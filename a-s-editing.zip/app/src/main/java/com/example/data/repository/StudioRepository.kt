package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.CustomPreset
import com.example.data.model.EditProject
import com.example.data.model.UserProfile
import com.example.data.remote.OperationType
import com.example.data.remote.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class StudioRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        val docRef = db.collection("users").document(userId)
        emitAll(
            docRef.snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            UserProfile::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else {
                        null
                    }
                }
                .catch { error ->
                    logStreamError(error, OperationType.GET, docRef.path, userId)
                    throw error
                }
        )
    }

    suspend fun ensureUserProfile(userId: String, displayName: String) {
        val docRef = db.collection("users").document(userId)
        try {
            val existing = docRef.get().await()
            if (!existing.exists()) {
                val safeName = displayName.trim().ifBlank { "Royal Creator" }.take(80)
                val payload = mapOf(
                    "userId" to userId,
                    "displayName" to safeName,
                    "studioHandle" to "A S Royal Studio",
                    "defaultQuality" to "HD_1080",
                    "watermarkEnabled" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
                docRef.set(payload).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    suspend fun updateProfilePreferences(
        userId: String,
        studioHandle: String,
        defaultQuality: String,
        watermarkEnabled: Boolean,
    ) {
        val uid = requireUserId()
        require(uid == userId) { "Authenticated user mismatch" }
        val docRef = db.collection("users").document(uid)
        val safeHandle = studioHandle.trim().ifBlank { "A S Royal Studio" }.take(40)
        try {
            docRef.update(
                mapOf(
                    "studioHandle" to safeHandle,
                    "defaultQuality" to defaultQuality,
                    "watermarkEnabled" to watermarkEnabled,
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    fun observeProjects(userId: String): Flow<List<EditProject>> = flow {
        val collectionRef = db.collection("users").document(userId).collection("projects")
        emitAll(
            collectionRef.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        EditProject::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.updatedAt ?: it.createdAt }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, collectionRef.path, userId)
                    throw error
                }
        )
    }

    suspend fun saveProject(project: EditProject): String {
        val uid = requireUserId()
        val collectionRef = db.collection("users").document(uid).collection("projects")
        val isNew = project.id.isBlank()
        val docRef = if (isNew) collectionRef.document() else collectionRef.document(project.id)
        val safeTitle = project.title.trim().ifBlank {
            if (project.mediaType == "video") "Royal Cinema Cut" else "Royal Portrait"
        }.take(100)
        val safeSourceUri = project.sourceUri.take(1000)
        val safePreset = project.presetName.trim().ifBlank { "Original" }.take(50)
        val safeOverlay = project.overlayText.take(60)
        val safeRotation = ((project.rotationDegrees % 360 + 360) % 360).let {
            if (it in listOf(0L, 90L, 180L, 270L)) it else 0L
        }

        try {
            if (isNew) {
                val payload = mapOf(
                    "userId" to uid,
                    "title" to safeTitle,
                    "mediaType" to if (project.mediaType == "video") "video" else "photo",
                    "sourceUri" to safeSourceUri,
                    "presetName" to safePreset,
                    "brightness" to project.brightness.coerceIn(-1.0, 1.0),
                    "contrast" to project.contrast.coerceIn(0.5, 2.0),
                    "saturation" to project.saturation.coerceIn(0.0, 2.0),
                    "warmth" to project.warmth.coerceIn(-1.0, 1.0),
                    "vignette" to project.vignette.coerceIn(0.0, 1.0),
                    "rotationDegrees" to safeRotation,
                    "cropAspect" to project.cropAspect,
                    "overlayText" to safeOverlay,
                    "trimStartMs" to project.trimStartMs.coerceAtLeast(0L),
                    "trimEndMs" to project.trimEndMs.coerceAtLeast(0L),
                    "playbackSpeed" to project.playbackSpeed.coerceIn(0.25, 4.0),
                    "muteAudio" to project.muteAudio,
                    "exportCount" to project.exportCount.coerceIn(0L, 100000L),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
                docRef.set(payload).await()
            } else {
                docRef.update(
                    mapOf(
                        "title" to safeTitle,
                        "sourceUri" to safeSourceUri,
                        "presetName" to safePreset,
                        "brightness" to project.brightness.coerceIn(-1.0, 1.0),
                        "contrast" to project.contrast.coerceIn(0.5, 2.0),
                        "saturation" to project.saturation.coerceIn(0.0, 2.0),
                        "warmth" to project.warmth.coerceIn(-1.0, 1.0),
                        "vignette" to project.vignette.coerceIn(0.0, 1.0),
                        "rotationDegrees" to safeRotation,
                        "cropAspect" to project.cropAspect,
                        "overlayText" to safeOverlay,
                        "trimStartMs" to project.trimStartMs.coerceAtLeast(0L),
                        "trimEndMs" to project.trimEndMs.coerceAtLeast(0L),
                        "playbackSpeed" to project.playbackSpeed.coerceIn(0.25, 4.0),
                        "muteAudio" to project.muteAudio,
                        "exportCount" to project.exportCount.coerceIn(0L, 100000L),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            }
            return docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(
                e,
                if (isNew) OperationType.CREATE else OperationType.UPDATE,
                docRef.path
            )
            throw e
        }
    }

    suspend fun incrementProjectExportCount(projectId: String) {
        val uid = requireUserId()
        if (projectId.isBlank()) return
        val docRef = db.collection("users").document(uid).collection("projects").document(projectId)
        try {
            docRef.update(
                mapOf(
                    "exportCount" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteProject(projectId: String) {
        val uid = requireUserId()
        require(projectId.isNotBlank()) { "Project ID must not be blank" }
        val docRef = db.collection("users").document(uid).collection("projects").document(projectId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    fun observeCustomPresets(userId: String): Flow<List<CustomPreset>> = flow {
        val collectionRef = db.collection("users").document(userId).collection("presets")
        emitAll(
            collectionRef.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        CustomPreset::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, collectionRef.path, userId)
                    throw error
                }
        )
    }

    suspend fun saveCustomPreset(preset: CustomPreset): String {
        val uid = requireUserId()
        val collectionRef = db.collection("users").document(uid).collection("presets")
        val docRef = collectionRef.document()
        val safeName = preset.name.trim().ifBlank { "Custom Grade" }.take(40)
        val payload = mapOf(
            "userId" to uid,
            "name" to safeName,
            "brightness" to preset.brightness.coerceIn(-1.0, 1.0),
            "contrast" to preset.contrast.coerceIn(0.5, 2.0),
            "saturation" to preset.saturation.coerceIn(0.0, 2.0),
            "warmth" to preset.warmth.coerceIn(-1.0, 1.0),
            "vignette" to preset.vignette.coerceIn(0.0, 1.0),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
        )
        try {
            docRef.set(payload).await()
            return docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteCustomPreset(presetId: String) {
        val uid = requireUserId()
        require(presetId.isNotBlank()) { "Preset ID must not be blank" }
        val docRef = db.collection("users").document(uid).collection("presets").document(presetId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    private fun logStreamError(
        error: Throwable,
        operationType: OperationType,
        path: String,
        expectedUid: String,
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, operationType, path)
        }
    }
}
