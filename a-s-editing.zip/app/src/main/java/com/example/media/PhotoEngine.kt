package com.example.media

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.ui.graphics.ColorMatrix as ComposeColorMatrix
import android.media.ExifInterface
import com.example.R
import com.example.data.model.CropAspect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object PhotoEngine {

    fun buildAndroidColorMatrix(
        brightness: Float,
        contrast: Float,
        saturation: Float,
        warmth: Float,
    ): ColorMatrix {
        val result = ColorMatrix()

        // Saturation
        val satMatrix = ColorMatrix().apply { setSaturation(saturation.coerceIn(0f, 2f)) }
        result.postConcat(satMatrix)

        // Contrast & Brightness
        val c = contrast.coerceIn(0.5f, 2f)
        val b = brightness.coerceIn(-1f, 1f) * 255f
        val translate = (-0.5f * c + 0.5f) * 255f + b
        val contrastBrightness = ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, translate,
                0f, c, 0f, 0f, translate,
                0f, 0f, c, 0f, translate,
                0f, 0f, 0f, 1f, 0f,
            )
        )
        result.postConcat(contrastBrightness)

        // Warmth (amber/blue shift)
        val w = warmth.coerceIn(-1f, 1f)
        if (w != 0f) {
            val rScale = (1f + w * 0.22f).coerceIn(0.6f, 1.4f)
            val gScale = (1f + w * 0.06f).coerceIn(0.8f, 1.2f)
            val bScale = (1f - w * 0.22f).coerceIn(0.6f, 1.4f)
            val warmthMatrix = ColorMatrix(
                floatArrayOf(
                    rScale, 0f, 0f, 0f, 0f,
                    0f, gScale, 0f, 0f, 0f,
                    0f, 0f, bScale, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f,
                )
            )
            result.postConcat(warmthMatrix)
        }
        return result
    }

    fun buildComposeColorMatrix(
        brightness: Float,
        contrast: Float,
        saturation: Float,
        warmth: Float,
    ): ComposeColorMatrix {
        val androidMatrix = buildAndroidColorMatrix(brightness, contrast, saturation, warmth)
        return ComposeColorMatrix(androidMatrix.array)
    }

    suspend fun loadBitmap(
        context: Context,
        uriString: String?,
        maxDimension: Int = 2048,
    ): Bitmap = withContext(Dispatchers.IO) {
        if (uriString.isNullOrBlank() || uriString == SAMPLE_PHOTO_URI) {
            val options = BitmapFactory.Options().apply { inMutable = false }
            return@withContext BitmapFactory.decodeResource(
                context.resources,
                R.drawable.img_sample_studio,
                options,
            )
        }

        val uri = Uri.parse(uriString)
        val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, boundsOptions)
        }

        val inSample = calculateInSampleSize(boundsOptions.outWidth, boundsOptions.outHeight, maxDimension)
        val decodeOptions = BitmapFactory.Options().apply { inSampleSize = inSample }
        val decoded = context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, decodeOptions)
        } ?: return@withContext BitmapFactory.decodeResource(context.resources, R.drawable.img_sample_studio)

        val exifRotation = try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                when (ExifInterface(stream).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (_: Exception) {
            0f
        }

        if (exifRotation != 0f) {
            val matrix = Matrix().apply { postRotate(exifRotation) }
            Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        } else {
            decoded
        }
    }

    fun renderEditedBitmap(
        source: Bitmap,
        brightness: Float,
        contrast: Float,
        saturation: Float,
        warmth: Float,
        vignette: Float,
        rotationDegrees: Int,
        cropAspect: CropAspect,
        overlayText: String,
        watermarkEnabled: Boolean,
        studioHandle: String,
    ): Bitmap {
        // 1. Rotate
        val rotated = if (rotationDegrees % 360 != 0) {
            val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
            Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
        } else {
            source
        }

        // 2. Crop to target aspect ratio
        val cropped = cropBitmapToAspect(rotated, cropAspect.ratio)
        val width = cropped.width
        val height = cropped.height
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)

        // 3. ColorMatrix grading
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(
                buildAndroidColorMatrix(brightness, contrast, saturation, warmth)
            )
        }
        canvas.drawBitmap(cropped, 0f, 0f, paint)

        // 4. Radial vignette
        if (vignette > 0.01f) {
            val radius = max(width, height) * 0.72f
            val edgeAlpha = (vignette.coerceIn(0f, 1f) * 215).roundToInt()
            val vignettePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    width / 2f,
                    height / 2f,
                    radius,
                    intArrayOf(
                        Color.TRANSPARENT,
                        Color.TRANSPARENT,
                        Color.argb(edgeAlpha, 7, 7, 9),
                    ),
                    floatArrayOf(0f, 0.45f, 1f),
                    Shader.TileMode.CLAMP,
                )
            }
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), vignettePaint)
        }

        // 5. Royal Gold Overlay Title / Studio Watermark
        val minDim = min(width, height).toFloat()
        if (overlayText.isNotBlank()) {
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(243, 213, 120)
                textSize = (minDim * 0.055f).coerceIn(28f, 120f)
                typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                setShadowLayer(10f, 0f, 3f, Color.argb(200, 7, 7, 9))
            }
            canvas.drawText(
                overlayText.trim(),
                width / 2f,
                height * 0.88f,
                textPaint,
            )
        }

        if (watermarkEnabled) {
            val badgeText = studioHandle.ifBlank { "A S EDITING" }.uppercase()
            val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(220, 212, 175, 55)
                textSize = (minDim * 0.026f).coerceIn(18f, 44f)
                typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
                letterSpacing = 0.12f
                textAlign = Paint.Align.RIGHT
                setShadowLayer(6f, 0f, 2f, Color.argb(200, 0, 0, 0))
            }
            canvas.drawText(
                badgeText,
                width - (minDim * 0.04f),
                height - (minDim * 0.04f),
                badgePaint,
            )
        }

        return output
    }

    suspend fun exportBitmapToGallery(
        context: Context,
        bitmap: Bitmap,
        projectTitle: String,
    ): Uri = withContext(Dispatchers.IO) {
        val cleanName = projectTitle
            .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
            .trim('_')
            .ifBlank { "AS_Edit" }
        val fileName = "${cleanName}_${System.currentTimeMillis()}.jpg"

        val resolver = context.contentResolver
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/AS Editing")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create MediaStore image entry")

            resolver.openOutputStream(uri)?.use { out ->
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)) {
                    throw IllegalStateException("Failed to compress JPEG image")
                }
            } ?: throw IllegalStateException("Could not open MediaStore output stream")

            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return@withContext uri
        } else {
            @Suppress("DEPRECATION")
            val picturesDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "AS Editing"
            )
            if (!picturesDir.exists()) picturesDir.mkdirs()
            val outFile = File(picturesDir, fileName)
            FileOutputStream(outFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
            }
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                @Suppress("DEPRECATION")
                put(MediaStore.Images.Media.DATA, outFile.absolutePath)
            }
            return@withContext resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: Uri.fromFile(outFile)
        }
    }

    private fun cropBitmapToAspect(bitmap: Bitmap, targetRatio: Float?): Bitmap {
        if (targetRatio == null) return bitmap
        val srcW = bitmap.width
        val srcH = bitmap.height
        val srcRatio = srcW.toFloat() / srcH.toFloat()
        if (kotlin.math.abs(srcRatio - targetRatio) < 0.01f) return bitmap

        return if (srcRatio > targetRatio) {
            val newW = (srcH * targetRatio).roundToInt().coerceIn(1, srcW)
            val xOffset = (srcW - newW) / 2
            Bitmap.createBitmap(bitmap, xOffset, 0, newW, srcH)
        } else {
            val newH = (srcW / targetRatio).roundToInt().coerceIn(1, srcH)
            val yOffset = (srcH - newH) / 2
            Bitmap.createBitmap(bitmap, 0, yOffset, srcW, newH)
        }
    }

    private fun calculateInSampleSize(width: Int, height: Int, maxDim: Int): Int {
        var inSampleSize = 1
        if (height > maxDim || width > maxDim) {
            val halfHeight = height / 2
            val halfWidth = width / 2
            while ((halfHeight / inSampleSize) >= maxDim && (halfWidth / inSampleSize) >= maxDim) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    const val SAMPLE_PHOTO_URI = "sample://royal_studio_photo"
}
