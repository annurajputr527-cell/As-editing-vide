package com.example.media

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.example.data.model.CropAspect
import com.example.data.model.ExportQuality
import com.example.data.model.GalleryExportItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

@OptIn(UnstableApi::class)
object VideoEngine {

    private var activeTransformer: Transformer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var progressRunnable: Runnable? = null

    fun startVideoExport(
        context: Context,
        sourceUri: Uri,
        title: String,
        trimStartMs: Long,
        trimEndMs: Long,
        muteAudio: Boolean,
        brightness: Float,
        contrast: Float,
        saturation: Float,
        warmth: Float,
        rotationDegrees: Int,
        cropAspect: CropAspect,
        exportQuality: ExportQuality,
        onProgress: (Int) -> Unit,
        onCompleted: (Uri) -> Unit,
        onError: (String) -> Unit,
    ) {
        cancelExport()

        val tempOutFile = File(context.cacheDir, "as_export_${System.currentTimeMillis()}.mp4")
        if (tempOutFile.exists()) tempOutFile.delete()

        val mediaItemBuilder = MediaItem.Builder().setUri(sourceUri)
        if (trimEndMs > trimStartMs && trimEndMs > 0L) {
            mediaItemBuilder.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(trimStartMs.coerceAtLeast(0L))
                    .setEndPositionMs(trimEndMs)
                    .build()
            )
        }

        val videoEffects = mutableListOf<Effect>()

        if (rotationDegrees % 360 != 0) {
            videoEffects.add(
                ScaleAndRotateTransformation.Builder()
                    .setRotationDegrees((360 - (rotationDegrees % 360)).toFloat())
                    .build()
            )
        }

        val contrastDelta = (contrast - 1f).coerceIn(-0.9f, 1f)
        if (kotlin.math.abs(contrastDelta) > 0.02f) {
            videoEffects.add(Contrast(contrastDelta))
        }

        val satDelta = ((saturation - 1f) * 100f).coerceIn(-100f, 100f)
        val lightDelta = (brightness * 50f).coerceIn(-100f, 100f)
        if (kotlin.math.abs(satDelta) > 2f || kotlin.math.abs(lightDelta) > 2f) {
            videoEffects.add(
                HslAdjustment.Builder()
                    .adjustSaturation(satDelta)
                    .adjustLightness(lightDelta)
                    .build()
            )
        }

        if (kotlin.math.abs(warmth) > 0.02f) {
            videoEffects.add(
                RgbAdjustment.Builder()
                    .setRedScale((1f + warmth * 0.22f).coerceIn(0.6f, 1.4f))
                    .setGreenScale((1f + warmth * 0.05f).coerceIn(0.8f, 1.2f))
                    .setBlueScale((1f - warmth * 0.22f).coerceIn(0.6f, 1.4f))
                    .build()
            )
        }

        cropAspect.ratio?.let { targetRatio ->
            videoEffects.add(
                Presentation.createForAspectRatio(
                    targetRatio,
                    Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP,
                )
            )
        }

        exportQuality.targetHeight?.let { targetH ->
            videoEffects.add(Presentation.createForHeight(targetH))
        }

        val audioProcessors = emptyList<AudioProcessor>()
        val editedMediaItem = EditedMediaItem.Builder(mediaItemBuilder.build())
            .setRemoveAudio(muteAudio)
            .setEffects(Effects(audioProcessors, videoEffects))
            .build()

        val transformer = Transformer.Builder(context)
            .addListener(
                object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        stopProgressPolling()
                        activeTransformer = null
                        onProgress(100)
                        try {
                            val galleryUri = copyVideoToGallery(context, tempOutFile, title)
                            tempOutFile.delete()
                            onCompleted(galleryUri)
                        } catch (e: Exception) {
                            tempOutFile.delete()
                            onError(e.localizedMessage ?: "Failed to save video to Gallery")
                        }
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException,
                    ) {
                        stopProgressPolling()
                        activeTransformer = null
                        tempOutFile.delete()
                        onError(exportException.localizedMessage ?: "Video export failed")
                    }
                }
            )
            .build()

        activeTransformer = transformer
        transformer.start(editedMediaItem, tempOutFile.absolutePath)

        val holder = ProgressHolder()
        val runnable = object : Runnable {
            override fun run() {
                val t = activeTransformer ?: return
                val state = t.getProgress(holder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(holder.progress.coerceIn(0, 99))
                }
                if (state != Transformer.PROGRESS_STATE_NOT_STARTED) {
                    mainHandler.postDelayed(this, 250L)
                }
            }
        }
        progressRunnable = runnable
        mainHandler.post(runnable)
    }

    fun cancelExport() {
        stopProgressPolling()
        activeTransformer?.cancel()
        activeTransformer = null
    }

    private fun stopProgressPolling() {
        progressRunnable?.let { mainHandler.removeCallbacks(it) }
        progressRunnable = null
    }

    private fun copyVideoToGallery(
        context: Context,
        sourceFile: File,
        projectTitle: String,
    ): Uri {
        val cleanName = projectTitle
            .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
            .trim('_')
            .ifBlank { "AS_Video" }
        val fileName = "${cleanName}_${System.currentTimeMillis()}.mp4"
        val resolver = context.contentResolver

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/AS Editing")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create MediaStore video entry")

            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(sourceFile).use { input ->
                    input.copyTo(out)
                }
            } ?: throw IllegalStateException("Could not open MediaStore video stream")

            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri
        } else {
            @Suppress("DEPRECATION")
            val moviesDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "AS Editing"
            )
            if (!moviesDir.exists()) moviesDir.mkdirs()
            val outFile = File(moviesDir, fileName)
            FileInputStream(sourceFile).use { input ->
                FileOutputStream(outFile).use { out ->
                    input.copyTo(out)
                }
            }
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                @Suppress("DEPRECATION")
                put(MediaStore.Video.Media.DATA, outFile.absolutePath)
            }
            return resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: Uri.fromFile(outFile)
        }
    }

    suspend fun queryStudioGalleryExports(context: Context): List<GalleryExportItem> =
        withContext(Dispatchers.IO) {
            val results = mutableListOf<GalleryExportItem>()
            val resolver = context.contentResolver

            // 1. Query exported images
            val imgProjection = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_ADDED,
            )
            val imgSelection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?"
            } else {
                "${MediaStore.Images.Media.DATA} LIKE ?"
            }
            val selectionArgs = arrayOf("%AS Editing%")

            runCatching {
                resolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    imgProjection,
                    imgSelection,
                    selectionArgs,
                    "${MediaStore.Images.Media.DATE_ADDED} DESC",
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                    val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        results.add(
                            GalleryExportItem(
                                id = id,
                                uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id),
                                displayName = cursor.getString(nameCol) ?: "AS_Photo.jpg",
                                isVideo = false,
                                sizeBytes = cursor.getLong(sizeCol),
                                durationMs = 0L,
                                dateAddedSec = cursor.getLong(dateCol),
                            )
                        )
                    }
                }
            }

            // 2. Query exported videos
            val vidProjection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.DATE_ADDED,
            )
            val vidSelection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?"
            } else {
                "${MediaStore.Video.Media.DATA} LIKE ?"
            }
            runCatching {
                resolver.query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    vidProjection,
                    vidSelection,
                    selectionArgs,
                    "${MediaStore.Video.Media.DATE_ADDED} DESC",
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                    val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                    val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                    val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        results.add(
                            GalleryExportItem(
                                id = id,
                                uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id),
                                displayName = cursor.getString(nameCol) ?: "AS_Video.mp4",
                                isVideo = true,
                                sizeBytes = cursor.getLong(sizeCol),
                                durationMs = cursor.getLong(durCol),
                                dateAddedSec = cursor.getLong(dateCol),
                            )
                        )
                    }
                }
            }

            results.sortedByDescending { it.dateAddedSec }
        }
}
