package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.ExportQuality
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonRuby
import com.example.ui.theme.EmeraldPrestige
import com.example.ui.theme.GoldBorderBright
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OnyxCard
import com.example.ui.theme.RoyalBorder
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalVoid
import com.example.ui.theme.SoftCream

@Composable
fun AccountScreen(
    userEmail: String?,
    userDisplayName: String?,
    userProfileState: UiState<UserProfile?>,
    onSavePreferences: (String, String, Boolean) -> Unit,
    onSignOut: () -> Unit,
) {
    val profile = (userProfileState as? UiState.Success)?.data
    var studioHandle by remember { mutableStateOf(profile?.studioHandle ?: "A S Royal Studio") }
    var selectedQuality by remember { mutableStateOf(profile?.defaultQuality ?: ExportQuality.HD_1080.key) }
    var watermarkEnabled by remember { mutableStateOf(profile?.watermarkEnabled ?: true) }
    var savedBanner by remember { mutableStateOf(false) }

    LaunchedEffect(profile) {
        if (profile != null) {
            studioHandle = profile.studioHandle
            selectedQuality = profile.defaultQuality
            watermarkEnabled = profile.watermarkEnabled
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = RoyalVoid,
                border = BorderStroke(1.dp, GoldBorderBright),
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Surface(
                        modifier = Modifier.size(56.dp),
                        shape = CircleShape,
                        color = OnyxCard,
                        border = BorderStroke(1.5.dp, ChampagneGold),
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.Person,
                                contentDescription = "Creator profile",
                                tint = ChampagneGold,
                                modifier = Modifier.size(28.dp),
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = userDisplayName?.ifBlank { null } ?: profile?.displayName ?: "Royal Creator",
                            style = MaterialTheme.typography.titleLarge,
                            color = IvoryWhite,
                        )
                        Text(
                            text = userEmail ?: "Google Authenticated Studio",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MutedSilver,
                        )
                    }
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = RoyalVoid,
                border = BorderStroke(1.dp, RoyalBorder),
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    Text(
                        text = "EXPORT & STUDIO PREFERENCES",
                        style = MaterialTheme.typography.labelSmall,
                        color = RoyalGold,
                    )

                    OutlinedTextField(
                        value = studioHandle,
                        onValueChange = {
                            studioHandle = it.take(40)
                            savedBanner = false
                        },
                        label = { Text("Studio Watermark Signature") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("studio_handle_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ChampagneGold,
                            unfocusedBorderColor = RoyalBorder,
                            focusedLabelColor = ChampagneGold,
                            unfocusedLabelColor = MutedSilver,
                            focusedTextColor = IvoryWhite,
                            unfocusedTextColor = IvoryWhite,
                        ),
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Default Video Export Resolution",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SoftCream,
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            ExportQuality.entries.forEach { quality ->
                                val selected = selectedQuality == quality.key
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        selectedQuality = quality.key
                                        savedBanner = false
                                    },
                                    label = { Text(quality.label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = RoyalGold,
                                        selectedLabelColor = ObsidianBlack,
                                        containerColor = OnyxCard,
                                        labelColor = SoftCream,
                                    ),
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Royal Gold Watermark",
                                style = MaterialTheme.typography.titleMedium,
                                color = IvoryWhite,
                            )
                            Text(
                                text = "Stamp your studio signature on exported photos",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MutedSilver,
                            )
                        }
                        Switch(
                            checked = watermarkEnabled,
                            onCheckedChange = {
                                watermarkEnabled = it
                                savedBanner = false
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = ObsidianBlack,
                                checkedTrackColor = RoyalGold,
                                uncheckedThumbColor = MutedSilver,
                                uncheckedTrackColor = OnyxCard,
                            ),
                        )
                    }

                    Button(
                        onClick = {
                            onSavePreferences(studioHandle, selectedQuality, watermarkEnabled)
                            savedBanner = true
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("save_preferences_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RoyalGold,
                            contentColor = ObsidianBlack,
                        ),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save Studio Preferences")
                    }

                    if (savedBanner) {
                        Text(
                            text = "Preferences synced to Royal Cloud.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = EmeraldPrestige,
                        )
                    }
                }
            }

            OutlinedButton(
                onClick = onSignOut,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("sign_out_button"),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, CrimsonRuby),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CrimsonRuby),
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Logout,
                    contentDescription = "Sign out",
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sign Out of Google Account")
            }
        }
    }
}
