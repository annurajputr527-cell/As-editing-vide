package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.EditProject
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonRuby
import com.example.ui.theme.GoldBorderBright
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OnyxCard
import com.example.ui.theme.RoyalBorder
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalVoid
import com.example.ui.theme.SoftCream
import com.example.ui.theme.VelvetSurface

@Composable
fun HomeScreen(
    userProfileState: UiState<UserProfile?>,
    projectsState: UiState<List<EditProject>>,
    onPickPhoto: () -> Unit,
    onTrySamplePhoto: () -> Unit,
    onPickVideo: () -> Unit,
    onOpenProject: (EditProject) -> Unit,
    onDeleteProject: (String) -> Unit,
) {
    val creatorName = (userProfileState as? UiState.Success)?.data?.displayName ?: "Royal Creator"

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = RoyalVoid,
                    border = BorderStroke(1.dp, GoldBorderBright),
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hero_studio),
                            contentDescription = "Royal editing suite banner",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp),
                            contentScale = ContentScale.Crop,
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp)
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            ObsidianBlack.copy(alpha = 0.25f),
                                            ObsidianBlack.copy(alpha = 0.88f),
                                        )
                                    )
                                ),
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp)
                                .padding(20.dp),
                            verticalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = ObsidianBlack.copy(alpha = 0.72f),
                                border = BorderStroke(1.dp, RoyalGold),
                            ) {
                                Text(
                                    text = "ROYAL STUDIO • $creatorName".uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ChampagneGold,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                )
                            }

                            Column {
                                Text(
                                    text = "Craft Cinematic Visuals",
                                    style = MaterialTheme.typography.displaySmall,
                                    color = IvoryWhite,
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "24K Color Grading • Media3 Video Trimming • Gallery Export",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SoftCream,
                                )
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    StudioActionCard(
                        title = "Photo Studio",
                        subtitle = "Pick photo & grade",
                        icon = Icons.Filled.PhotoCamera,
                        isPrimary = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("launch_photo_editor"),
                        onClick = onPickPhoto,
                    )
                    StudioActionCard(
                        title = "Video Studio",
                        subtitle = "Trim, grade & export",
                        icon = Icons.Filled.MovieCreation,
                        isPrimary = false,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("launch_video_editor"),
                        onClick = onPickVideo,
                    )
                }
            }

            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(onClick = onTrySamplePhoto)
                        .testTag("try_sample_photo_button"),
                    shape = RoundedCornerShape(16.dp),
                    color = VelvetSurface,
                    border = BorderStroke(1.dp, RoyalBorder),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_sample_studio),
                            contentDescription = "Sample architectural studio photo",
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop,
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Try Royal Sample Canvas",
                                style = MaterialTheme.typography.titleMedium,
                                color = ChampagneGold,
                            )
                            Text(
                                text = "Test 24K Gold filters & Gallery export instantly",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MutedSilver,
                            )
                        }
                        Icon(
                            imageVector = Icons.Filled.AutoFixHigh,
                            contentDescription = null,
                            tint = RoyalGold,
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = "CLOUD PROJECTS",
                        style = MaterialTheme.typography.labelSmall,
                        color = RoyalGold,
                    )
                    val count = (projectsState as? UiState.Success)?.data?.size ?: 0
                    Text(
                        text = "$count SAVED",
                        style = MaterialTheme.typography.labelSmall,
                        color = MutedSilver,
                    )
                }
            }

            when (projectsState) {
                is UiState.Loading -> {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 32.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            CircularProgressIndicator(color = RoyalGold)
                        }
                    }
                }

                is UiState.Error -> {
                    item {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            color = OnyxCard,
                            border = BorderStroke(1.dp, CrimsonRuby),
                        ) {
                            Text(
                                text = projectsState.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = CrimsonRuby,
                                modifier = Modifier.padding(16.dp),
                            )
                        }
                    }
                }

                is UiState.Success -> {
                    val projects = projectsState.data
                    if (projects.isEmpty()) {
                        item {
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(18.dp),
                                color = RoyalVoid,
                                border = BorderStroke(1.dp, RoyalBorder),
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.MovieCreation,
                                        contentDescription = null,
                                        tint = RoyalGold.copy(alpha = 0.7f),
                                        modifier = Modifier.size(36.dp),
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "No Cloud Projects Yet",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = IvoryWhite,
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Start a Photo or Video edit and tap Save to sync your grade settings.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MutedSilver,
                                    )
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Button(
                                            onClick = onTrySamplePhoto,
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = RoyalGold,
                                                contentColor = ObsidianBlack,
                                            ),
                                        ) {
                                            Text("Open Sample Photo")
                                        }
                                        OutlinedButton(
                                            onClick = onPickVideo,
                                            border = BorderStroke(1.dp, RoyalGold),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampagneGold),
                                        ) {
                                            Text("Pick Video")
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        items(projects, key = { it.id }) { project ->
                            ProjectRowCard(
                                project = project,
                                onOpen = { onOpenProject(project) },
                                onDelete = { onDeleteProject(project.id) },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StudioActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    isPrimary: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Surface(
        modifier = modifier
            .height(126.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = if (isPrimary) OnyxCard else VelvetSurface,
        border = BorderStroke(1.dp, if (isPrimary) ChampagneGold else RoyalBorder),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Surface(
                modifier = Modifier.size(40.dp),
                shape = RoundedCornerShape(12.dp),
                color = if (isPrimary) RoyalGold else ObsidianBlack,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = if (isPrimary) ObsidianBlack else ChampagneGold,
                        modifier = Modifier.size(22.dp),
                    )
                }
            }
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = IvoryWhite,
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedSilver,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun ProjectRowCard(
    project: EditProject,
    onOpen: () -> Unit,
    onDelete: () -> Unit,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onOpen)
            .testTag("project_card_${project.id}"),
        shape = RoundedCornerShape(16.dp),
        color = RoyalVoid,
        border = BorderStroke(1.dp, RoyalBorder),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Surface(
                modifier = Modifier.size(48.dp),
                shape = RoundedCornerShape(12.dp),
                color = OnyxCard,
                border = BorderStroke(1.dp, GoldBorderBright),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (project.mediaType == "video") Icons.Filled.PlayArrow else Icons.Filled.PhotoCamera,
                        contentDescription = project.mediaType,
                        tint = ChampagneGold,
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = project.title.ifBlank { "Untitled Project" },
                    style = MaterialTheme.typography.titleMedium,
                    color = IvoryWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${project.mediaType.uppercase()} • ${project.presetName} • ${project.exportCount} exports",
                    style = MaterialTheme.typography.labelSmall,
                    color = RoyalGold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.testTag("delete_project_${project.id}"),
            ) {
                Icon(
                    imageVector = Icons.Filled.DeleteOutline,
                    contentDescription = "Delete project",
                    tint = MutedSilver,
                )
            }
        }
    }
}
