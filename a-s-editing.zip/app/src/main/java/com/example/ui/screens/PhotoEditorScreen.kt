package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.CropAspect
import com.example.data.model.CustomPreset
import com.example.data.model.FilterPreset
import com.example.data.model.RoyalFilterPresets
import com.example.data.model.UiState
import com.example.media.PhotoEngine
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.EmeraldPrestige
import com.example.ui.theme.GoldBorderBright
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OnyxCard
import com.example.ui.theme.RoyalBorder
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalVoid
import com.example.ui.theme.SoftCream
import com.example.ui.theme.VelvetSurface
import com.example.ui.viewmodel.PhotoEditorUiState
import java.util.Locale
import kotlin.math.max

@Composable
fun PhotoEditorScreen(
    state: PhotoEditorUiState,
    customPresetsState: UiState<List<CustomPreset>>,
    onBack: () -> Unit,
    onPickAnotherPhoto: () -> Unit,
    onTitleChange: (String) -> Unit,
    onApplyPreset: (FilterPreset) -> Unit,
    onApplyCustomPreset: (CustomPreset) -> Unit,
    onSaveCustomPreset: (String) -> Unit,
    onDeleteCustomPreset: (String) -> Unit,
    onBrightnessChange: (Float) -> Unit,
    onContrastChange: (Float) -> Unit,
    onSaturationChange: (Float) -> Unit,
    onWarmthChange: (Float) -> Unit,
    onVignetteChange: (Float) -> Unit,
    onRotate90: () -> Unit,
    onCropAspectChange: (CropAspect) -> Unit,
    onOverlayTextChange: (String) -> Unit,
    onResetAdjustments: () -> Unit,
    onToggleCompare: () -> Unit,
    onSaveToCloud: () -> Unit,
    onExportToGallery: () -> Unit,
    onDismissStatus: () -> Unit,
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var activeToolTab by remember { mutableIntStateOf(0) }
    var showSavePresetDialog by remember { mutableStateOf(false) }
    var newPresetName by remember { mutableStateOf("") }

    LaunchedEffect(state.statusMessage) {
        val msg = state.statusMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            onDismissStatus()
        }
    }

    Scaffold(
        containerColor = ObsidianBlack,
        contentWindowInsets = WindowInsets.statusBars,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBars),
                color = RoyalVoid,
                border = BorderStroke(1.dp, RoyalBorder),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("photo_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Studio",
                            tint = ChampagneGold,
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = state.title.ifBlank { "Royal Portrait" },
                            style = MaterialTheme.typography.titleMedium,
                            color = IvoryWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = "PHOTO STUDIO • ${state.presetName.uppercase()}",
                            style = MaterialTheme.typography.labelSmall,
                            color = RoyalGold,
                        )
                    }
                    IconButton(onClick = onPickAnotherPhoto, modifier = Modifier.testTag("photo_pick_button")) {
                        Icon(
                            imageVector = Icons.Filled.PhotoLibrary,
                            contentDescription = "Pick another photo",
                            tint = SoftCream,
                        )
                    }
                    IconButton(onClick = onToggleCompare, modifier = Modifier.testTag("photo_compare_button")) {
                        Icon(
                            imageVector = Icons.Filled.Compare,
                            contentDescription = "Compare original",
                            tint = if (state.isComparingOriginal) ChampagneGold else SoftCream,
                        )
                    }
                    IconButton(
                        onClick = onSaveToCloud,
                        enabled = !state.isSavingCloud,
                        modifier = Modifier.testTag("photo_cloud_save_button"),
                    ) {
                        if (state.isSavingCloud) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = ChampagneGold,
                                strokeWidth = 2.dp,
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.CloudUpload,
                                contentDescription = "Save to cloud",
                                tint = ChampagneGold,
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            Surface(
                color = RoyalVoid,
                border = BorderStroke(1.dp, RoyalBorder),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (state.exportedUri != null) {
                        OutlinedButton(
                            onClick = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "image/jpeg"
                                    putExtra(Intent.EXTRA_STREAM, state.exportedUri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Royal Photo"))
                            },
                            modifier = Modifier.height(50.dp),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, ChampagneGold),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampagneGold),
                        ) {
                            Icon(Icons.Filled.Share, contentDescription = "Share exported photo")
                        }
                    }

                    Button(
                        onClick = onExportToGallery,
                        enabled = !state.isExporting && state.previewBitmap != null,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("photo_export_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RoyalGold,
                            contentColor = ObsidianBlack,
                        ),
                    ) {
                        if (state.isExporting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = ObsidianBlack,
                                strokeWidth = 2.5.dp,
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("EXPORTING TO GALLERY...")
                        } else {
                            Icon(Icons.Filled.Download, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("EXPORT TO GALLERY")
                        }
                    }
                }
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(ObsidianBlack),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                // Live Graded Canvas Preview
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = RoyalVoid,
                    border = BorderStroke(1.dp, GoldBorderBright),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(state.cropAspect.ratio ?: (4f / 3f))
                            .clip(RoundedCornerShape(20.dp))
                            .background(ObsidianBlack),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (state.isLoadingImage) {
                            CircularProgressIndicator(color = RoyalGold)
                        } else if (state.previewBitmap != null) {
                            val matrix = remember(
                                state.brightness,
                                state.contrast,
                                state.saturation,
                                state.warmth,
                                state.isComparingOriginal,
                            ) {
                                if (state.isComparingOriginal) {
                                    null
                                } else {
                                    PhotoEngine.buildComposeColorMatrix(
                                        brightness = state.brightness,
                                        contrast = state.contrast,
                                        saturation = state.saturation,
                                        warmth = state.warmth,
                                    )
                                }
                            }

                            Image(
                                bitmap = state.previewBitmap.asImageBitmap(),
                                contentDescription = "Photo preview canvas",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        rotationZ = state.rotationDegrees.toFloat()
                                    },
                                contentScale = ContentScale.Crop,
                                colorFilter = matrix?.let { ColorFilter.colorMatrix(it) },
                            )

                            if (!state.isComparingOriginal && state.vignette > 0.01f) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val radius = max(size.width, size.height) * 0.72f
                                    drawRect(
                                        brush = Brush.radialGradient(
                                            colors = listOf(
                                                Color.Transparent,
                                                Color.Transparent,
                                                ObsidianBlack.copy(alpha = (state.vignette * 0.85f).coerceIn(0f, 0.9f)),
                                            ),
                                            center = Offset(size.width / 2f, size.height / 2f),
                                            radius = radius,
                                        )
                                    )
                                }
                            }

                            if (!state.isComparingOriginal && state.overlayText.isNotBlank()) {
                                Text(
                                    text = state.overlayText,
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = ChampagneGold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier
                                        .align(Alignment.BottomCenter)
                                        .padding(bottom = 20.dp, start = 16.dp, end = 16.dp),
                                )
                            }

                            if (state.isComparingOriginal) {
                                Surface(
                                    modifier = Modifier
                                        .align(Alignment.TopStart)
                                        .padding(12.dp),
                                    shape = RoundedCornerShape(50),
                                    color = ObsidianBlack.copy(alpha = 0.8f),
                                    border = BorderStroke(1.dp, ChampagneGold),
                                ) {
                                    Text(
                                        text = "ORIGINAL",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = ChampagneGold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    )
                                }
                            }
                        }
                    }
                }

                // Tool Mode Switcher
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    listOf("Presets", "Adjust", "Transform & Text").forEachIndexed { idx, label ->
                        FilterChip(
                            selected = activeToolTab == idx,
                            onClick = { activeToolTab = idx },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = RoyalGold,
                                selectedLabelColor = ObsidianBlack,
                                containerColor = VelvetSurface,
                                labelColor = SoftCream,
                            ),
                        )
                    }
                }

                when (activeToolTab) {
                    0 -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "ROYAL FILTER PRESETS",
                                style = MaterialTheme.typography.labelSmall,
                                color = RoyalGold,
                            )
                            TextButton(onClick = { showSavePresetDialog = true }) {
                                Icon(
                                    imageVector = Icons.Filled.BookmarkAdd,
                                    contentDescription = null,
                                    tint = ChampagneGold,
                                    modifier = Modifier.size(16.dp),
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Save Look", color = ChampagneGold)
                            }
                        }

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(vertical = 4.dp),
                        ) {
                            items(RoyalFilterPresets.builtIn) { preset ->
                                val selected = state.presetName == preset.name
                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(14.dp))
                                        .clickable { onApplyPreset(preset) }
                                        .testTag("preset_${preset.name}"),
                                    shape = RoundedCornerShape(14.dp),
                                    color = if (selected) RoyalGold else OnyxCard,
                                    border = BorderStroke(1.dp, if (selected) ChampagneGold else RoyalBorder),
                                ) {
                                    Text(
                                        text = preset.name,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (selected) ObsidianBlack else IvoryWhite,
                                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                                    )
                                }
                            }
                        }

                        val customPresets = (customPresetsState as? UiState.Success)?.data.orEmpty()
                        if (customPresets.isNotEmpty()) {
                            Text(
                                text = "YOUR SAVED GRADES",
                                style = MaterialTheme.typography.labelSmall,
                                color = MutedSilver,
                            )
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                items(customPresets, key = { it.id }) { preset ->
                                    val selected = state.presetName == preset.name
                                    Surface(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(14.dp))
                                            .clickable { onApplyCustomPreset(preset) },
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (selected) RoyalGold else VelvetSurface,
                                        border = BorderStroke(1.dp, if (selected) ChampagneGold else RoyalBorder),
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(start = 14.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            Text(
                                                text = preset.name,
                                                style = MaterialTheme.typography.labelLarge,
                                                color = if (selected) ObsidianBlack else ChampagneGold,
                                            )
                                            IconButton(
                                                onClick = { onDeleteCustomPreset(preset.id) },
                                                modifier = Modifier.size(28.dp),
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.Close,
                                                    contentDescription = "Delete preset",
                                                    tint = if (selected) ObsidianBlack else MutedSilver,
                                                    modifier = Modifier.size(16.dp),
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            color = RoyalVoid,
                            border = BorderStroke(1.dp, RoyalBorder),
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(
                                        text = "COLOR & LIGHT",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = RoyalGold,
                                    )
                                    TextButton(onClick = onResetAdjustments) {
                                        Icon(Icons.Filled.Refresh, contentDescription = null, tint = ChampagneGold, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Reset", color = ChampagneGold)
                                    }
                                }

                                RoyalSlider("Brightness", state.brightness, -0.5f..0.5f, onBrightnessChange)
                                RoyalSlider("Contrast", state.contrast, 0.5f..1.8f, onContrastChange)
                                RoyalSlider("Saturation", state.saturation, 0f..2f, onSaturationChange)
                                RoyalSlider("Warmth", state.warmth, -0.6f..0.6f, onWarmthChange)
                                RoyalSlider("Vignette", state.vignette, 0f..1f, onVignetteChange)
                            }
                        }
                    }

                    2 -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            color = RoyalVoid,
                            border = BorderStroke(1.dp, RoyalBorder),
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp),
                            ) {
                                OutlinedTextField(
                                    value = state.title,
                                    onValueChange = onTitleChange,
                                    label = { Text("Project Title") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = ChampagneGold,
                                        unfocusedBorderColor = RoyalBorder,
                                        focusedLabelColor = ChampagneGold,
                                        unfocusedLabelColor = MutedSilver,
                                        focusedTextColor = IvoryWhite,
                                        unfocusedTextColor = IvoryWhite,
                                    ),
                                )

                                OutlinedTextField(
                                    value = state.overlayText,
                                    onValueChange = onOverlayTextChange,
                                    label = { Text("Gold Title / Watermark Overlay") },
                                    placeholder = { Text("e.g., ROYAL EDITION") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = ChampagneGold,
                                        unfocusedBorderColor = RoyalBorder,
                                        focusedLabelColor = ChampagneGold,
                                        unfocusedLabelColor = MutedSilver,
                                        focusedTextColor = IvoryWhite,
                                        unfocusedTextColor = IvoryWhite,
                                    ),
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text("Rotation: ${state.rotationDegrees}°", color = SoftCream)
                                    OutlinedButton(
                                        onClick = onRotate90,
                                        border = BorderStroke(1.dp, RoyalGold),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampagneGold),
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.RotateRight, contentDescription = "Rotate 90°")
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Rotate 90°")
                                    }
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = "CROP ASPECT RATIO",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = RoyalGold,
                                    )
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        items(CropAspect.entries) { aspect ->
                                            val selected = state.cropAspect == aspect
                                            FilterChip(
                                                selected = selected,
                                                onClick = { onCropAspectChange(aspect) },
                                                label = { Text(aspect.label) },
                                                colors = FilterChipDefaults.filterChipColors(
                                                    selectedContainerColor = RoyalGold,
                                                    selectedLabelColor = ObsidianBlack,
                                                    containerColor = OnyxCard,
                                                    labelColor = SoftCream,
                                                ),
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSavePresetDialog) {
        AlertDialog(
            onDismissRequest = { showSavePresetDialog = false },
            containerColor = RoyalVoid,
            titleContentColor = ChampagneGold,
            textContentColor = IvoryWhite,
            title = { Text("Save Royal Color Grade") },
            text = {
                OutlinedTextField(
                    value = newPresetName,
                    onValueChange = { newPresetName = it.take(40) },
                    label = { Text("Preset Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ChampagneGold,
                        unfocusedBorderColor = RoyalBorder,
                        focusedTextColor = IvoryWhite,
                        unfocusedTextColor = IvoryWhite,
                    ),
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveCustomPreset(newPresetName)
                        newPresetName = ""
                        showSavePresetDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RoyalGold,
                        contentColor = ObsidianBlack,
                    ),
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSavePresetDialog = false }) {
                    Text("Cancel", color = MutedSilver)
                }
            },
        )
    }
}

@Composable
internal fun RoyalSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium, color = SoftCream)
            Text(
                text = String.format(Locale.US, "%.2f", value),
                style = MaterialTheme.typography.labelSmall,
                color = ChampagneGold,
            )
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = ChampagneGold,
                activeTrackColor = RoyalGold,
                inactiveTrackColor = OnyxCard,
            ),
        )
    }
}
