package com.example.ui.screens

import android.content.Intent
import androidx.annotation.OptIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.data.model.CropAspect
import com.example.data.model.CustomPreset
import com.example.data.model.FilterPreset
import com.example.data.model.RoyalFilterPresets
import com.example.data.model.UiState
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonRuby
import com.example.ui.theme.GoldBorderBright
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MutedSilver
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.OnyxCard
import com.example.ui.theme.RoyalBorder
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalVoid
import com.example.ui.theme.SoftCream
import com.example.ui.theme.VelvetSurface
import com.example.ui.viewmodel.VideoEditorUiState
import kotlinx.coroutines.delay
import java.util.Locale

@OptIn(UnstableApi::class)
@Composable
fun VideoEditorScreen(
    state: VideoEditorUiState,
    customPresetsState: UiState<List<CustomPreset>>,
    onBack: () -> Unit,
    onPickVideo: () -> Unit,
    onTitleChange: (String) -> Unit,
    onDurationResolved: (Long) -> Unit,
    onApplyPreset: (FilterPreset) -> Unit,
    onApplyCustomPreset: (CustomPreset) -> Unit,
    onBrightnessChange: (Float) -> Unit,
    onContrastChange: (Float) -> Unit,
    onSaturationChange: (Float) -> Unit,
    onWarmthChange: (Float) -> Unit,
    onTrimChange: (Long, Long) -> Unit,
    onSpeedChange: (Float) -> Unit,
    onMuteChange: (Boolean) -> Unit,
    onRotate90: () -> Unit,
    onCropAspectChange: (CropAspect) -> Unit,
    onOverlayTextChange: (String) -> Unit,
    onResetAdjustments: () -> Unit,
    onSaveToCloud: () -> Unit,
    onExportToGallery: () -> Unit,
    onCancelExport: () -> Unit,
    onDismissStatus: () -> Unit,
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var activeTab by remember { mutableIntStateOf(0) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentPosMs by remember { mutableLongStateOf(0L) }

    val exoPlayer = remember(context) {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
        }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && exoPlayer.duration > 0L) {
                    onDurationResolved(exoPlayer.duration)
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    LaunchedEffect(state.sourceUri) {
        if (state.sourceUri.isNotBlank()) {
            exoPlayer.setMediaItem(MediaItem.fromUri(state.sourceUri))
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
        }
    }

    LaunchedEffect(state.playbackSpeed, state.muteAudio) {
        exoPlayer.setPlaybackSpeed(state.playbackSpeed)
        exoPlayer.volume = if (state.muteAudio) 0f else 1f
    }

    LaunchedEffect(isPlaying, state.trimStartMs, state.trimEndMs) {
        while (true) {
            currentPosMs = exoPlayer.currentPosition
            if (state.trimEndMs > state.trimStartMs && currentPosMs >= state.trimEndMs) {
                exoPlayer.seekTo(state.trimStartMs)
            }
            delay(150L)
        }
    }

    LaunchedEffect(state.statusMessage) {
        val msg = state.statusMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            onDismissStatus()
        }
    }

    Scaffold(
        containerColor = ObsidianBlack,
        contentWindowInsets = WindowInsets.statusBars,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBars),
                color = RoyalVoid,
                border = BorderStroke(1.dp, RoyalBorder),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("video_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Studio",
                            tint = ChampagneGold,
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = state.title.ifBlank { "Royal Cinema Cut" },
                            style = MaterialTheme.typography.titleMedium,
                            color = IvoryWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = "VIDEO STUDIO • ${state.presetName.uppercase()}",
                            style = MaterialTheme.typography.labelSmall,
                            color = RoyalGold,
                        )
                    }
                    IconButton(onClick = onPickVideo, modifier = Modifier.testTag("video_pick_button")) {
                        Icon(
                            imageVector = Icons.Filled.MovieCreation,
                            contentDescription = "Pick another video",
                            tint = SoftCream,
                        )
                    }
                    IconButton(
                        onClick = onSaveToCloud,
                        enabled = !state.isSavingCloud,
                        modifier = Modifier.testTag("video_cloud_save_button"),
                    ) {
                        if (state.isSavingCloud) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = ChampagneGold,
                                strokeWidth = 2.dp,
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.CloudUpload,
                                contentDescription = "Save video project",
                                tint = ChampagneGold,
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            Surface(
                color = RoyalVoid,
                border = BorderStroke(1.dp, RoyalBorder),
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (state.isExporting) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "Media3 Transcoding MP4... ${state.exportProgress}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = ChampagneGold,
                            )
                            TextButton(onClick = onCancelExport) {
                                Icon(Icons.Filled.Close, contentDescription = null, tint = CrimsonRuby, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Cancel", color = CrimsonRuby)
                            }
                        }
                        LinearProgressIndicator(
                            progress = { (state.exportProgress / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth(),
                            color = RoyalGold,
                            trackColor = OnyxCard,
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        if (state.exportedUri != null) {
                            OutlinedButton(
                                onClick = {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "video/mp4"
                                        putExtra(Intent.EXTRA_STREAM, state.exportedUri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share Royal Video"))
                                },
                                modifier = Modifier.height(50.dp),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, ChampagneGold),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampagneGold),
                            ) {
                                Icon(Icons.Filled.Share, contentDescription = "Share exported video")
                            }
                        }

                        Button(
                            onClick = onExportToGallery,
                            enabled = !state.isExporting && state.sourceUri.isNotBlank(),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("video_export_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = RoyalGold,
                                contentColor = ObsidianBlack,
                            ),
                        ) {
                            Icon(Icons.Filled.Download, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (state.isExporting) "RENDERING MP4..." else "EXPORT MP4 TO GALLERY")
                        }
                    }
                }
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(ObsidianBlack),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = RoyalVoid,
                    border = BorderStroke(1.dp, GoldBorderBright),
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(state.cropAspect.ratio ?: (16f / 9f))
                                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                                .background(ObsidianBlack),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (state.sourceUri.isBlank()) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Filled.MovieCreation,
                                        contentDescription = null,
                                        tint = RoyalGold,
                                        modifier = Modifier.size(40.dp),
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("No Video Selected", color = IvoryWhite)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Button(
                                        onClick = onPickVideo,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = RoyalGold,
                                            contentColor = ObsidianBlack,
                                        ),
                                    ) {
                                        Text("Pick Video")
                                    }
                                }
                            } else {
                                AndroidView(
                                    factory = { ctx ->
                                        PlayerView(ctx).apply {
                                            player = exoPlayer
                                            useController = false
                                        }
                                    },
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }
                        }

                        // Playback bar
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        if (exoPlayer.isPlaying) {
                                            exoPlayer.pause()
                                        } else {
                                            if (exoPlayer.currentPosition < state.trimStartMs ||
                                                (state.trimEndMs > 0 && exoPlayer.currentPosition >= state.trimEndMs)
                                            ) {
                                                exoPlayer.seekTo(state.trimStartMs)
                                            }
                                            exoPlayer.play()
                                        }
                                    },
                                    modifier = Modifier.testTag("video_play_pause_button"),
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                        contentDescription = if (isPlaying) "Pause" else "Play",
                                        tint = ChampagneGold,
                                    )
                                }
                                Text(
                                    text = "${formatTimeMs(currentPosMs)} / ${formatTimeMs(state.durationMs)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SoftCream,
                                )
                            }

                            IconButton(onClick = { onMuteChange(!state.muteAudio) }) {
                                Icon(
                                    imageVector = if (state.muteAudio) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = if (state.muteAudio) "Unmute audio" else "Mute audio",
                                    tint = if (state.muteAudio) CrimsonRuby else ChampagneGold,
                                )
                            }
                        }
                    }
                }

                // Tool Tabs
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    listOf("Trim & Speed", "Color Grade", "Title & Ratio").forEachIndexed { idx, label ->
                        FilterChip(
                            selected = activeTab == idx,
                            onClick = { activeTab = idx },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = RoyalGold,
                                selectedLabelColor = ObsidianBlack,
                                containerColor = VelvetSurface,
                                labelColor = SoftCream,
                            ),
                        )
                    }
                }

                when (activeTab) {
                    0 -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            color = RoyalVoid,
                            border = BorderStroke(1.dp, RoyalBorder),
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp),
                            ) {
                                val totalMs = state.durationMs.coerceAtLeast(1000L)
                                val startVal = state.trimStartMs.coerceIn(0L, totalMs).toFloat()
                                val endVal = (if (state.trimEndMs > 0L) state.trimEndMs else totalMs)
                                    .coerceIn(startVal.toLong(), totalMs)
                                    .toFloat()

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text("TRIM TIMELINE", style = MaterialTheme.typography.labelSmall, color = RoyalGold)
                                    Text(
                                        text = "${formatTimeMs(startVal.toLong())} - ${formatTimeMs(endVal.toLong())}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = ChampagneGold,
                                    )
                                }

                                RangeSlider(
                                    value = startVal..endVal,
                                    onValueChange = { range ->
                                        onTrimChange(range.start.toLong(), range.endInclusive.toLong())
                                    },
                                    valueRange = 0f..totalMs.toFloat(),
                                    colors = SliderDefaults.colors(
                                        thumbColor = ChampagneGold,
                                        activeTrackColor = RoyalGold,
                                        inactiveTrackColor = OnyxCard,
                                    ),
                                )

                                Text("PLAYBACK SPEED", style = MaterialTheme.typography.labelSmall, color = RoyalGold)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    listOf(0.5f, 1.0f, 1.5f, 2.0f).forEach { speed ->
                                        val selected = kotlin.math.abs(state.playbackSpeed - speed) < 0.05f
                                        FilterChip(
                                            selected = selected,
                                            onClick = { onSpeedChange(speed) },
                                            label = { Text("${speed}x") },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = RoyalGold,
                                                selectedLabelColor = ObsidianBlack,
                                                containerColor = OnyxCard,
                                                labelColor = SoftCream,
                                            ),
                                        )
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(vertical = 4.dp),
                        ) {
                            items(RoyalFilterPresets.builtIn) { preset ->
                                val selected = state.presetName == preset.name
                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(14.dp))
                                        .clickable { onApplyPreset(preset) },
                                    shape = RoundedCornerShape(14.dp),
                                    color = if (selected) RoyalGold else OnyxCard,
                                    border = BorderStroke(1.dp, if (selected) ChampagneGold else RoyalBorder),
                                ) {
                                    Text(
                                        text = preset.name,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (selected) ObsidianBlack else IvoryWhite,
                                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                                    )
                                }
                            }
                        }

                        val customPresets = (customPresetsState as? UiState.Success)?.data.orEmpty()
                        if (customPresets.isNotEmpty()) {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(customPresets, key = { it.id }) { preset ->
                                    val selected = state.presetName == preset.name
                                    Surface(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(14.dp))
                                            .clickable { onApplyCustomPreset(preset) },
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (selected) RoyalGold else VelvetSurface,
                                        border = BorderStroke(1.dp, if (selected) ChampagneGold else RoyalBorder),
                                    ) {
                                        Text(
                                            text = preset.name,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = if (selected) ObsidianBlack else ChampagneGold,
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                        )
                                    }
                                }
                            }
                        }

                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            color = RoyalVoid,
                            border = BorderStroke(1.dp, RoyalBorder),
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text("VIDEO COLOR GRADE", style = MaterialTheme.typography.labelSmall, color = RoyalGold)
                                    TextButton(onClick = onResetAdjustments) {
                                        Icon(Icons.Filled.Refresh, contentDescription = null, tint = ChampagneGold, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Reset", color = ChampagneGold)
                                    }
                                }
                                RoyalSlider("Brightness", state.brightness, -0.5f..0.5f, onBrightnessChange)
                                RoyalSlider("Contrast", state.contrast, 0.5f..1.8f, onContrastChange)
                                RoyalSlider("Saturation", state.saturation, 0f..2f, onSaturationChange)
                                RoyalSlider("Warmth", state.warmth, -0.6f..0.6f, onWarmthChange)
                            }
                        }
                    }

                    2 -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            color = RoyalVoid,
                            border = BorderStroke(1.dp, RoyalBorder),
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp),
                            ) {
                                OutlinedTextField(
                                    value = state.title,
                                    onValueChange = onTitleChange,
                                    label = { Text("Project Title") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = ChampagneGold,
                                        unfocusedBorderColor = RoyalBorder,
                                        focusedLabelColor = ChampagneGold,
                                        unfocusedLabelColor = MutedSilver,
                                        focusedTextColor = IvoryWhite,
                                        unfocusedTextColor = IvoryWhite,
                                    ),
                                )
                                OutlinedTextField(
                                    value = state.overlayText,
                                    onValueChange = onOverlayTextChange,
                                    label = { Text("Project Notes / Watermark Tag") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = ChampagneGold,
                                        unfocusedBorderColor = RoyalBorder,
                                        focusedLabelColor = ChampagneGold,
                                        unfocusedLabelColor = MutedSilver,
                                        focusedTextColor = IvoryWhite,
                                        unfocusedTextColor = IvoryWhite,
                                    ),
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text("Rotation: ${state.rotationDegrees}°", color = SoftCream)
                                    OutlinedButton(
                                        onClick = onRotate90,
                                        border = BorderStroke(1.dp, RoyalGold),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampagneGold),
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.RotateRight, contentDescription = "Rotate 90°")
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Rotate 90°")
                                    }
                                }
                                Text("EXPORT ASPECT RATIO", style = MaterialTheme.typography.labelSmall, color = RoyalGold)
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(CropAspect.entries) { aspect ->
                                        val selected = state.cropAspect == aspect
                                        FilterChip(
                                            selected = selected,
                                            onClick = { onCropAspectChange(aspect) },
                                            label = { Text(aspect.label) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = RoyalGold,
                                                selectedLabelColor = ObsidianBlack,
                                                containerColor = OnyxCard,
                                                labelColor = SoftCream,
                                            ),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatTimeMs(ms: Long): String {
    val totalSec = (ms.coerceAtLeast(0L) / 1000L)
    val mins = totalSec / 60L
    val secs = totalSec % 60L
    return String.format(Locale.US, "%02d:%02d", mins, secs)
}
