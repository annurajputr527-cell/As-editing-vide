package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Royal Black & 24K Gold Palette
val ObsidianBlack = Color(0xFF070709)
val RoyalVoid = Color(0xFF0E0E13)
val VelvetSurface = Color(0xFF15151D)
val OnyxCard = Color(0xFF1C1C26)
val ElevatedOnyx = Color(0xFF242431)

val RoyalGold = Color(0xFFD4AF37)
val ChampagneGold = Color(0xFFF3D578)
val AntiqueGold = Color(0xFFB58E2A)
val BurnishedBronze = Color(0xFF7D611B)
val RoyalBorder = Color(0xFF2E2718)
val GoldBorderBright = Color(0xFF6B531D)

val IvoryWhite = Color(0xFFF6F2E9)
val SoftCream = Color(0xFFDCD5C7)
val MutedSilver = Color(0xFF9C968B)

val CrimsonRuby = Color(0xFFE05263)
val EmeraldPrestige = Color(0xFF34C782)
