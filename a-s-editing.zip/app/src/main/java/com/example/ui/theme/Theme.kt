package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val RoyalDarkColorScheme = darkColorScheme(
    primary = RoyalGold,
    onPrimary = ObsidianBlack,
    primaryContainer = BurnishedBronze,
    onPrimaryContainer = ChampagneGold,
    secondary = ChampagneGold,
    onSecondary = ObsidianBlack,
    secondaryContainer = OnyxCard,
    onSecondaryContainer = ChampagneGold,
    tertiary = AntiqueGold,
    onTertiary = ObsidianBlack,
    background = ObsidianBlack,
    onBackground = IvoryWhite,
    surface = RoyalVoid,
    onSurface = IvoryWhite,
    surfaceVariant = VelvetSurface,
    onSurfaceVariant = MutedSilver,
    surfaceContainerLowest = ObsidianBlack,
    surfaceContainerLow = RoyalVoid,
    surfaceContainer = VelvetSurface,
    surfaceContainerHigh = OnyxCard,
    surfaceContainerHighest = ElevatedOnyx,
    outline = RoyalBorder,
    outlineVariant = GoldBorderBright,
    error = CrimsonRuby,
    onError = IvoryWhite,
)

private val RoyalShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun ASEditingTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = RoyalDarkColorScheme,
        typography = Typography,
        shapes = RoyalShapes,
        content = content,
    )
}
