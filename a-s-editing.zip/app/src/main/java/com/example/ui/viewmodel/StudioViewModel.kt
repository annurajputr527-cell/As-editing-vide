package com.example.ui.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.CropAspect
import com.example.data.model.CustomPreset
import com.example.data.model.EditProject
import com.example.data.model.ExportQuality
import com.example.data.model.FilterPreset
import com.example.data.model.GalleryExportItem
import com.example.data.model.RoyalFilterPresets
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.repository.StudioRepository
import com.example.media.PhotoEngine
import com.example.media.VideoEngine
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PhotoEditorUiState(
    val projectId: String = "",
    val title: String = "Royal Portrait",
    val sourceUri: String = PhotoEngine.SAMPLE_PHOTO_URI,
    val previewBitmap: Bitmap? = null,
    val isLoadingImage: Boolean = false,
    val presetName: String = "Original",
    val brightness: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val warmth: Float = 0f,
    val vignette: Float = 0f,
    val rotationDegrees: Int = 0,
    val cropAspect: CropAspect = CropAspect.ORIGINAL,
    val overlayText: String = "",
    val isComparingOriginal: Boolean = false,
    val isSavingCloud: Boolean = false,
    val isExporting: Boolean = false,
    val exportCount: Long = 0L,
    val createdAt: com.google.firebase.Timestamp? = null,
    val statusMessage: String? = null,
    val exportedUri: Uri? = null,
)

data class VideoEditorUiState(
    val projectId: String = "",
    val title: String = "Royal Cinema Cut",
    val sourceUri: String = "",
    val durationMs: Long = 0L,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 0L,
    val playbackSpeed: Float = 1f,
    val muteAudio: Boolean = false,
    val presetName: String = "Original",
    val brightness: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val warmth: Float = 0f,
    val vignette: Float = 0f,
    val rotationDegrees: Int = 0,
    val cropAspect: CropAspect = CropAspect.ORIGINAL,
    val overlayText: String = "",
    val isSavingCloud: Boolean = false,
    val isExporting: Boolean = false,
    val exportProgress: Int = 0,
    val exportCount: Long = 0L,
    val createdAt: com.google.firebase.Timestamp? = null,
    val statusMessage: String? = null,
    val exportedUri: Uri? = null,
)

class StudioViewModel(
    private val repository: StudioRepository,
    private val currentUserId: String,
    initialDisplayName: String,
) : ViewModel() {

    val userProfile: StateFlow<UiState<UserProfile?>> = repository.observeUserProfile(currentUserId)
        .map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
        .catch { error ->
            val root = unwrapFirestoreError(error)
            if (root == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing profile", root ?: error)
            emit(UiState.Error((root ?: error).message ?: "Failed to load profile"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading,
        )

    val projectsState: StateFlow<UiState<List<EditProject>>> = repository.observeProjects(currentUserId)
        .map<List<EditProject>, UiState<List<EditProject>>> { UiState.Success(it) }
        .catch { error ->
            val root = unwrapFirestoreError(error)
            if (root == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing projects", root ?: error)
            emit(UiState.Error((root ?: error).message ?: "Failed to load projects"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading,
        )

    val customPresetsState: StateFlow<UiState<List<CustomPreset>>> = repository.observeCustomPresets(currentUserId)
        .map<List<CustomPreset>, UiState<List<CustomPreset>>> { UiState.Success(it) }
        .catch { error ->
            val root = unwrapFirestoreError(error)
            if (root == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing presets", root ?: error)
            emit(UiState.Error((root ?: error).message ?: "Failed to load presets"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading,
        )

    private val _photoState = MutableStateFlow(PhotoEditorUiState())
    val photoState: StateFlow<PhotoEditorUiState> = _photoState.asStateFlow()

    private val _videoState = MutableStateFlow(VideoEditorUiState())
    val videoState: StateFlow<VideoEditorUiState> = _videoState.asStateFlow()

    private val _galleryExports = MutableStateFlow<List<GalleryExportItem>>(emptyList())
    val galleryExports: StateFlow<List<GalleryExportItem>> = _galleryExports.asStateFlow()

    private val _isLoadingExports = MutableStateFlow(false)
    val isLoadingExports: StateFlow<Boolean> = _isLoadingExports.asStateFlow()

    init {
        viewModelScope.launch {
            runCatching { repository.ensureUserProfile(currentUserId, initialDisplayName) }
                .onFailure { Log.w(TAG, "Failed to ensure profile", it) }
        }
    }

    fun openPhotoForEditing(context: Context, uri: Uri?, project: EditProject?) {
        val resolvedUri = uri?.toString() ?: project?.sourceUri?.takeIf { it.isNotBlank() }
            ?: PhotoEngine.SAMPLE_PHOTO_URI
        val crop = CropAspect.entries.firstOrNull { it.name == project?.cropAspect } ?: CropAspect.ORIGINAL
        _photoState.value = PhotoEditorUiState(
            projectId = project?.id.orEmpty(),
            title = project?.title?.ifBlank { "Royal Portrait" } ?: "Royal Portrait",
            sourceUri = resolvedUri,
            isLoadingImage = true,
            presetName = project?.presetName?.ifBlank { "Original" } ?: "Original",
            brightness = (project?.brightness ?: 0.0).toFloat(),
            contrast = (project?.contrast ?: 1.0).toFloat(),
            saturation = (project?.saturation ?: 1.0).toFloat(),
            warmth = (project?.warmth ?: 0.0).toFloat(),
            vignette = (project?.vignette ?: 0.0).toFloat(),
            rotationDegrees = (project?.rotationDegrees ?: 0L).toInt(),
            cropAspect = crop,
            overlayText = project?.overlayText.orEmpty(),
            exportCount = project?.exportCount ?: 0L,
            createdAt = project?.createdAt,
        )
        viewModelScope.launch {
            val bitmap = runCatching { PhotoEngine.loadBitmap(context, resolvedUri) }
                .getOrElse { PhotoEngine.loadBitmap(context, PhotoEngine.SAMPLE_PHOTO_URI) }
            _photoState.update { it.copy(previewBitmap = bitmap, isLoadingImage = false) }
        }
    }

    fun updatePhotoTitle(title: String) {
        _photoState.update { it.copy(title = title.take(100)) }
    }

    fun applyPhotoPreset(preset: FilterPreset) {
        _photoState.update {
            it.copy(
                presetName = preset.name,
                brightness = preset.brightness,
                contrast = preset.contrast,
                saturation = preset.saturation,
                warmth = preset.warmth,
                vignette = preset.vignette,
            )
        }
    }

    fun applyCustomPresetToPhoto(preset: CustomPreset) {
        _photoState.update {
            it.copy(
                presetName = preset.name,
                brightness = preset.brightness.toFloat(),
                contrast = preset.contrast.toFloat(),
                saturation = preset.saturation.toFloat(),
                warmth = preset.warmth.toFloat(),
                vignette = preset.vignette.toFloat(),
            )
        }
    }

    fun saveCurrentPhotoGradeAsPreset(name: String) {
        val current = _photoState.value
        val safeName = name.trim().ifBlank { "Royal Custom" }.take(40)
        viewModelScope.launch {
            runCatching {
                repository.saveCustomPreset(
                    CustomPreset(
                        userId = currentUserId,
                        name = safeName,
                        brightness = current.brightness.toDouble(),
                        contrast = current.contrast.toDouble(),
                        saturation = current.saturation.toDouble(),
                        warmth = current.warmth.toDouble(),
                        vignette = current.vignette.toDouble(),
                    )
                )
            }.onSuccess {
                _photoState.update { it.copy(presetName = safeName, statusMessage = "Saved preset \"$safeName\"") }
            }.onFailure { e ->
                _photoState.update { it.copy(statusMessage = e.localizedMessage ?: "Failed to save preset") }
            }
        }
    }

    fun deleteCustomPreset(presetId: String) {
        viewModelScope.launch {
            runCatching { repository.deleteCustomPreset(presetId) }
        }
    }

    fun updatePhotoAdjustments(transform: (PhotoEditorUiState) -> PhotoEditorUiState) {
        _photoState.update { current -> transform(current) }
    }

    fun rotatePhoto90() {
        _photoState.update { it.copy(rotationDegrees = (it.rotationDegrees + 90) % 360) }
    }

    fun togglePhotoCompare() {
        _photoState.update { it.copy(isComparingOriginal = !it.isComparingOriginal) }
    }

    fun savePhotoProjectToCloud() {
        val s = _photoState.value
        if (s.isSavingCloud) return
        _photoState.update { it.copy(isSavingCloud = true) }
        viewModelScope.launch {
            val model = EditProject(
                id = s.projectId,
                userId = currentUserId,
                title = s.title.ifBlank { "Royal Portrait" },
                mediaType = "photo",
                sourceUri = s.sourceUri,
                presetName = s.presetName,
                brightness = s.brightness.toDouble(),
                contrast = s.contrast.toDouble(),
                saturation = s.saturation.toDouble(),
                warmth = s.warmth.toDouble(),
                vignette = s.vignette.toDouble(),
                rotationDegrees = s.rotationDegrees.toLong(),
                cropAspect = s.cropAspect.name,
                overlayText = s.overlayText,
                exportCount = s.exportCount,
                createdAt = s.createdAt,
            )
            runCatching { repository.saveProject(model) }
                .onSuccess { docId ->
                    _photoState.update {
                        it.copy(
                            projectId = docId,
                            isSavingCloud = false,
                            statusMessage = "Project synced to Royal Cloud",
                        )
                    }
                }
                .onFailure { e ->
                    _photoState.update {
                        it.copy(
                            isSavingCloud = false,
                            statusMessage = e.localizedMessage ?: "Cloud sync failed",
                        )
                    }
                }
        }
    }

    fun exportPhotoToGallery(context: Context) {
        val s = _photoState.value
        val source = s.previewBitmap ?: return
        if (s.isExporting) return

        val profile = (userProfile.value as? UiState.Success)?.data
        val watermarkEnabled = profile?.watermarkEnabled ?: true
        val studioHandle = profile?.studioHandle ?: "A S Royal Studio"

        _photoState.update { it.copy(isExporting = true, statusMessage = null) }
        viewModelScope.launch {
            runCatching {
                val rendered = PhotoEngine.renderEditedBitmap(
                    source = source,
                    brightness = s.brightness,
                    contrast = s.contrast,
                    saturation = s.saturation,
                    warmth = s.warmth,
                    vignette = s.vignette,
                    rotationDegrees = s.rotationDegrees,
                    cropAspect = s.cropAspect,
                    overlayText = s.overlayText,
                    watermarkEnabled = watermarkEnabled,
                    studioHandle = studioHandle,
                )
                val savedUri = PhotoEngine.exportBitmapToGallery(context, rendered, s.title)
                if (s.projectId.isNotBlank()) {
                    runCatching { repository.incrementProjectExportCount(s.projectId) }
                }
                savedUri
            }.onSuccess { uri ->
                _photoState.update {
                    it.copy(
                        isExporting = false,
                        exportCount = it.exportCount + 1,
                        exportedUri = uri,
                        statusMessage = "Exported to Gallery (Pictures/AS Editing)",
                    )
                }
                refreshGalleryExports(context)
            }.onFailure { e ->
                _photoState.update {
                    it.copy(
                        isExporting = false,
                        statusMessage = e.localizedMessage ?: "Gallery export failed",
                    )
                }
            }
        }
    }

    fun clearPhotoStatus() {
        _photoState.update { it.copy(statusMessage = null) }
    }

    fun openVideoForEditing(uri: Uri?, project: EditProject?) {
        val resolvedUri = uri?.toString() ?: project?.sourceUri.orEmpty()
        val crop = CropAspect.entries.firstOrNull { it.name == project?.cropAspect } ?: CropAspect.ORIGINAL
        _videoState.value = VideoEditorUiState(
            projectId = project?.id.orEmpty(),
            title = project?.title?.ifBlank { "Royal Cinema Cut" } ?: "Royal Cinema Cut",
            sourceUri = resolvedUri,
            trimStartMs = project?.trimStartMs ?: 0L,
            trimEndMs = project?.trimEndMs ?: 0L,
            playbackSpeed = (project?.playbackSpeed ?: 1.0).toFloat(),
            muteAudio = project?.muteAudio ?: false,
            presetName = project?.presetName?.ifBlank { "Original" } ?: "Original",
            brightness = (project?.brightness ?: 0.0).toFloat(),
            contrast = (project?.contrast ?: 1.0).toFloat(),
            saturation = (project?.saturation ?: 1.0).toFloat(),
            warmth = (project?.warmth ?: 0.0).toFloat(),
            vignette = (project?.vignette ?: 0.0).toFloat(),
            rotationDegrees = (project?.rotationDegrees ?: 0L).toInt(),
            cropAspect = crop,
            overlayText = project?.overlayText.orEmpty(),
            exportCount = project?.exportCount ?: 0L,
            createdAt = project?.createdAt,
        )
    }

    fun updateVideoTitle(title: String) {
        _videoState.update { it.copy(title = title.take(100)) }
    }

    fun onVideoDurationResolved(durationMs: Long) {
        if (durationMs <= 0L) return
        _videoState.update { current ->
            val resolvedEnd = if (current.trimEndMs <= 0L || current.trimEndMs > durationMs) {
                durationMs
            } else {
                current.trimEndMs
            }
            val resolvedStart = current.trimStartMs.coerceIn(0L, (resolvedEnd - 500L).coerceAtLeast(0L))
            current.copy(
                durationMs = durationMs,
                trimStartMs = resolvedStart,
                trimEndMs = resolvedEnd,
            )
        }
    }

    fun applyVideoPreset(preset: FilterPreset) {
        _videoState.update {
            it.copy(
                presetName = preset.name,
                brightness = preset.brightness,
                contrast = preset.contrast,
                saturation = preset.saturation,
                warmth = preset.warmth,
                vignette = preset.vignette,
            )
        }
    }

    fun applyCustomPresetToVideo(preset: CustomPreset) {
        _videoState.update {
            it.copy(
                presetName = preset.name,
                brightness = preset.brightness.toFloat(),
                contrast = preset.contrast.toFloat(),
                saturation = preset.saturation.toFloat(),
                warmth = preset.warmth.toFloat(),
                vignette = preset.vignette.toFloat(),
            )
        }
    }

    fun updateVideoAdjustments(transform: (VideoEditorUiState) -> VideoEditorUiState) {
        _videoState.update { current -> transform(current) }
    }

    fun rotateVideo90() {
        _videoState.update { it.copy(rotationDegrees = (it.rotationDegrees + 90) % 360) }
    }

    fun saveVideoProjectToCloud() {
        val s = _videoState.value
        if (s.isSavingCloud) return
        _videoState.update { it.copy(isSavingCloud = true) }
        viewModelScope.launch {
            val model = EditProject(
                id = s.projectId,
                userId = currentUserId,
                title = s.title.ifBlank { "Royal Cinema Cut" },
                mediaType = "video",
                sourceUri = s.sourceUri,
                presetName = s.presetName,
                brightness = s.brightness.toDouble(),
                contrast = s.contrast.toDouble(),
                saturation = s.saturation.toDouble(),
                warmth = s.warmth.toDouble(),
                vignette = s.vignette.toDouble(),
                rotationDegrees = s.rotationDegrees.toLong(),
                cropAspect = s.cropAspect.name,
                overlayText = s.overlayText,
                trimStartMs = s.trimStartMs,
                trimEndMs = s.trimEndMs,
                playbackSpeed = s.playbackSpeed.toDouble(),
                muteAudio = s.muteAudio,
                exportCount = s.exportCount,
                createdAt = s.createdAt,
            )
            runCatching { repository.saveProject(model) }
                .onSuccess { docId ->
                    _videoState.update {
                        it.copy(
                            projectId = docId,
                            isSavingCloud = false,
                            statusMessage = "Video project synced to Royal Cloud",
                        )
                    }
                }
                .onFailure { e ->
                    _videoState.update {
                        it.copy(
                            isSavingCloud = false,
                            statusMessage = e.localizedMessage ?: "Cloud sync failed",
                        )
                    }
                }
        }
    }

    fun exportVideoToGallery(context: Context) {
        val s = _videoState.value
        if (s.sourceUri.isBlank() || s.isExporting) return

        val profile = (userProfile.value as? UiState.Success)?.data
        val quality = ExportQuality.entries.firstOrNull { it.key == profile?.defaultQuality }
            ?: ExportQuality.HD_1080

        _videoState.update { it.copy(isExporting = true, exportProgress = 0, statusMessage = null) }
        VideoEngine.startVideoExport(
            context = context,
            sourceUri = Uri.parse(s.sourceUri),
            title = s.title,
            trimStartMs = s.trimStartMs,
            trimEndMs = s.trimEndMs,
            muteAudio = s.muteAudio,
            brightness = s.brightness,
            contrast = s.contrast,
            saturation = s.saturation,
            warmth = s.warmth,
            rotationDegrees = s.rotationDegrees,
            cropAspect = s.cropAspect,
            exportQuality = quality,
            onProgress = { pct ->
                _videoState.update { it.copy(exportProgress = pct) }
            },
            onCompleted = { uri ->
                viewModelScope.launch {
                    if (s.projectId.isNotBlank()) {
                        runCatching { repository.incrementProjectExportCount(s.projectId) }
                    }
                    refreshGalleryExports(context)
                }
                _videoState.update {
                    it.copy(
                        isExporting = false,
                        exportProgress = 100,
                        exportCount = it.exportCount + 1,
                        exportedUri = uri,
                        statusMessage = "Video exported to Gallery (Movies/AS Editing)",
                    )
                }
            },
            onError = { err ->
                _videoState.update {
                    it.copy(
                        isExporting = false,
                        exportProgress = 0,
                        statusMessage = err,
                    )
                }
            },
        )
    }

    fun cancelVideoExport() {
        VideoEngine.cancelExport()
        _videoState.update {
            it.copy(
                isExporting = false,
                exportProgress = 0,
                statusMessage = "Export cancelled",
            )
        }
    }

    fun clearVideoStatus() {
        _videoState.update { it.copy(statusMessage = null) }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            runCatching { repository.deleteProject(projectId) }
        }
    }

    fun refreshGalleryExports(context: Context) {
        viewModelScope.launch {
            _isLoadingExports.value = true
            val list = runCatching { VideoEngine.queryStudioGalleryExports(context) }
                .getOrDefault(emptyList())
            _galleryExports.value = list
            _isLoadingExports.value = false
        }
    }

    fun updateProfilePreferences(
        studioHandle: String,
        defaultQuality: String,
        watermarkEnabled: Boolean,
    ) {
        viewModelScope.launch {
            runCatching {
                repository.updateProfilePreferences(
                    userId = currentUserId,
                    studioHandle = studioHandle,
                    defaultQuality = defaultQuality,
                    watermarkEnabled = watermarkEnabled,
                )
            }
        }
    }

    private fun unwrapFirestoreError(error: Throwable): FirebaseFirestoreException? {
        return generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
    }

    private companion object {
        const val TAG = "StudioVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
