package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.CustomPreset
import com.example.data.model.EditProject
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StudioRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun ensureUserProfile_and_saveProject_succeedsForAuthenticatedOwner() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val repo = StudioRepository(firestore)

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.ensureUserProfile(aliceUid, "Alice Royal")
        }

        val projectId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.saveProject(
                EditProject(
                    userId = aliceUid,
                    title = "Royal Gold Reel",
                    mediaType = "video",
                    sourceUri = "content://media/external/video/media/99",
                    presetName = "24K Gold",
                    brightness = 0.04,
                    contrast = 1.18,
                    saturation = 1.22,
                    warmth = 0.28,
                    vignette = 0.25,
                    rotationDegrees = 0L,
                    cropAspect = "CINEMA_16_9",
                    overlayText = "A S STUDIO",
                    trimStartMs = 0L,
                    trimEndMs = 8000L,
                    playbackSpeed = 1.0,
                    muteAudio = false,
                )
            )
        }
        assertTrue(projectId.isNotBlank())

        val projects = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeProjects(aliceUid).first { list -> list.any { it.id == projectId } }
        }
        assertTrue(projects.any { it.id == projectId && it.title == "Royal Gold Reel" })
    }

    @Test
    fun saveCustomPreset_and_deleteCustomPreset_succeedsForOwner() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val repo = StudioRepository(firestore)

        val presetId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.saveCustomPreset(
                CustomPreset(
                    userId = aliceUid,
                    name = "Obsidian Amber",
                    brightness = 0.02,
                    contrast = 1.25,
                    saturation = 0.9,
                    warmth = 0.3,
                    vignette = 0.35,
                )
            )
        }
        assertTrue(presetId.isNotBlank())

        val presets = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeCustomPresets(aliceUid).first { list -> list.any { it.id == presetId } }
        }
        assertTrue(presets.any { it.id == presetId })

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.deleteCustomPreset(presetId)
        }
    }

    @Test
    fun observeProjects_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = StudioRepository(firestore)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.saveProject(
                EditProject(
                    userId = aliceUid,
                    title = "Alice Private Cut",
                    mediaType = "photo",
                    sourceUri = "sample://royal_studio_photo",
                )
            )
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = StudioRepository(firestore)
        val thrown = try {
            withTimeout(FLOW_TIMEOUT_MS) {
                bobRepo.observeProjects(aliceUid).first()
            }
            null
        } catch (e: Exception) {
            e
        }

        val firestoreError = checkNotNull(thrown?.unwrapFirestoreException()) {
            "Expected nested FirebaseFirestoreException, got $thrown"
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreError.code)
    }

    @Test
    fun observeProjects_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = StudioRepository(firestore)

        val thrown = try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeProjects("some_user_id").first()
            }
            null
        } catch (e: Exception) {
            e
        }

        val firestoreError = checkNotNull(thrown?.unwrapFirestoreException()) {
            "Expected nested FirebaseFirestoreException, got $thrown"
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreError.code)
    }

    private companion object {
        const val ALICE_EMAIL = "alice_studio@test.com"
        const val BOB_EMAIL = "bob_studio@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
