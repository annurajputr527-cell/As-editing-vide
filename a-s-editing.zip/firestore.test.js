const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const DATABASE_ID = "ai-studio-android-aseditin-a076c67d-0338-4d5d-8dd5-5980a42c0aff";
const ALICE_UID = "alice_uid_123";
const BOB_UID = "bob_uid_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validProfile(uid) {
  const now = new Date(Date.now() - 1000);
  return {
    userId: uid,
    displayName: "Royal Creator",
    studioHandle: "AS Royal Studio",
    defaultQuality: "HD_1080",
    watermarkEnabled: true,
    createdAt: now,
    updatedAt: now,
  };
}

function validProject(uid) {
  const now = new Date(Date.now() - 1000);
  return {
    userId: uid,
    title: "Golden Hour Reel",
    mediaType: "video",
    sourceUri: "content://media/external/video/media/42",
    presetName: "24K Gold",
    brightness: 0.1,
    contrast: 1.2,
    saturation: 1.15,
    warmth: 0.25,
    vignette: 0.3,
    rotationDegrees: 0,
    cropAspect: "CINEMA_16_9",
    overlayText: "A S STUDIO",
    trimStartMs: 0,
    trimEndMs: 12000,
    playbackSpeed: 1.0,
    muteAudio: false,
    exportCount: 0,
    createdAt: now,
    updatedAt: now,
  };
}

function validPreset(uid) {
  const now = new Date(Date.now() - 1000);
  return {
    userId: uid,
    name: "Midnight Amber",
    brightness: 0.05,
    contrast: 1.25,
    saturation: 0.9,
    warmth: 0.35,
    vignette: 0.4,
    createdAt: now,
    updatedAt: now,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write user profile or projects", async () => {
  const db = testEnv.unauthenticatedContext().firestore();
  await assertFails(db.collection("users").doc(ALICE_UID).get());
  await assertFails(db.collection("users").doc(ALICE_UID).collection("projects").get());
  await assertFails(db.collection("users").doc(ALICE_UID).collection("projects").doc("p1").set(validProject(ALICE_UID)));
});

test("Authenticated owner can create and update own profile", async () => {
  const db = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(db.collection("users").doc(ALICE_UID).set(validProfile(ALICE_UID)));
  await assertSucceeds(
    db.collection("users").doc(ALICE_UID).update({
      studioHandle: "Royal Gold Films",
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("User cannot create profile with spoofed userId or ghost field", async () => {
  const db = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(db.collection("users").doc(ALICE_UID).set(validProfile(BOB_UID)));
  await assertFails(
    db.collection("users").doc(ALICE_UID).set({
      ...validProfile(ALICE_UID),
      isAdmin: true,
    })
  );
});

test("Authenticated owner can CRUD own projects and presets", async () => {
  const db = testEnv.authenticatedContext(ALICE_UID).firestore();
  const projectRef = db.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1");
  await assertSucceeds(projectRef.set(validProject(ALICE_UID)));
  await assertSucceeds(db.collection("users").doc(ALICE_UID).collection("projects").get());
  await assertSucceeds(
    projectRef.update({
      exportCount: 1,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  const presetRef = db.collection("users").doc(ALICE_UID).collection("presets").doc("preset_1");
  await assertSucceeds(presetRef.set(validPreset(ALICE_UID)));
  await assertSucceeds(presetRef.delete());
});

test("Cross-user access to projects and presets is denied", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_alice").set(validProject(ALICE_UID))
  );

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_alice").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("projects").get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_alice").update({
      title: "Hacked",
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("Invalid project bounds or immutable mediaType mutation fails", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const projectRef = aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_bounds");
  await assertFails(
    projectRef.set({
      ...validProject(ALICE_UID),
      brightness: 5.0,
    })
  );
  await assertSucceeds(projectRef.set(validProject(ALICE_UID)));
  await assertFails(
    projectRef.update({
      mediaType: "photo",
      updatedAt: new Date(Date.now() - 500),
    })
  );
});
